import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

const navy = Color(0xFF123A56);
const blue = Color(0xFF1E74B0);
const bg = Color(0xFFF4F7FA);

void main() => runApp(const WaseemMedicalApp());

class WaseemMedicalApp extends StatefulWidget {
  const WaseemMedicalApp({super.key});
  @override State<WaseemMedicalApp> createState() => _AppState();
}
class _AppState extends State<WaseemMedicalApp> {
  ThemeMode mode = ThemeMode.light;
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'نظام وسيم الطبي PRO',
    themeMode: mode,
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: blue, scaffoldBackgroundColor: bg, fontFamily: 'sans-serif'),
    darkTheme: ThemeData.dark(useMaterial3: true),
    home: LoginPage(onTheme: () => setState(() => mode = mode == ThemeMode.light ? ThemeMode.dark : ThemeMode.light)),
  );
}

class LoginPage extends StatefulWidget {
  final VoidCallback onTheme;
  const LoginPage({super.key, required this.onTheme});
  @override State<LoginPage> createState() => _LoginState();
}
class _LoginState extends State<LoginPage> {
  final u = TextEditingController(text: 'admin');
  final p = TextEditingController(text: '1234');
  bool busy = false;
  Future<void> login() async {
    setState(() => busy = true);
    await Future<void>.delayed(const Duration(milliseconds: 250));
    if (!mounted) return;
    if (u.text.trim().toLowerCase() == 'admin' && p.text == '1234') {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('logged_in', true);
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const Shell()));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('بيانات الدخول غير صحيحة')));
    }
    setState(() => busy = false);
  }
  @override Widget build(BuildContext context) => Directionality(textDirection: TextDirection.rtl, child: Scaffold(
    body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(22), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 520), child: Column(children: [
      Container(height: 110, width: double.infinity, decoration: BoxDecoration(color: navy, borderRadius: BorderRadius.circular(28)), child: const Center(child: Text('✚', style: TextStyle(fontSize: 58, color: Colors.white)))),
      const SizedBox(height: 18), const Text('نظام وسيم الطبي PRO', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800, color: navy)),
      const Text('إدارة المراكز والعيادات والعلاج الطبيعي والتأهيل', style: TextStyle(color: Colors.black54)), const SizedBox(height: 22),
      Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
        const Align(alignment: Alignment.centerRight, child: Text('بيانات الدخول', style: TextStyle(fontWeight: FontWeight.bold))), const SizedBox(height: 12),
        TextField(controller: u, textDirection: TextDirection.rtl, decoration: const InputDecoration(labelText: 'اسم المستخدم', prefixIcon: Icon(Icons.person_outline), border: OutlineInputBorder())), const SizedBox(height: 12),
        TextField(controller: p, obscureText: true, textDirection: TextDirection.rtl, decoration: const InputDecoration(labelText: 'كلمة المرور', prefixIcon: Icon(Icons.lock_outline), border: OutlineInputBorder())), const SizedBox(height: 16),
        SizedBox(width: double.infinity, height: 54, child: FilledButton(onPressed: busy ? null : login, child: Text(busy ? 'جارٍ الدخول...' : 'دخول إلى النظام'))), const SizedBox(height: 10),
        const Text('للتجربة: admin / 1234', style: TextStyle(fontSize: 12, color: Colors.grey)),
      ]))), const SizedBox(height: 18), const Text('تطوير وتصميم: وسيم الفرح لخدمات التقنية والأنظمة\n774486588', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
    ]))))),
  ));
}

class Shell extends StatefulWidget { const Shell({super.key}); @override State<Shell> createState() => _ShellState(); }
class _ShellState extends State<Shell> {
  int index = 0;
  final pages = const [Dashboard(), PatientsPage(), AppointmentsPage(), SessionsPage(), MorePage()];
  @override Widget build(BuildContext context) => Directionality(textDirection: TextDirection.rtl, child: Scaffold(
    appBar: AppBar(backgroundColor: navy, foregroundColor: Colors.white, title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('نظام وسيم الطبي PRO', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), Text('المركز الأول للعلاج الطبيعي والتأهيل – دمت', style: TextStyle(fontSize: 10))]), actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)), PopupMenuButton<String>(onSelected: (v) { if(v=='logout') Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => LoginPage(onTheme: () {}))); }, itemBuilder: (_) => const [PopupMenuItem(value: 'logout', child: Text('تسجيل الخروج'))])]),
    body: pages[index],
    bottomNavigationBar: NavigationBar(selectedIndex: index, onDestinationSelected: (v) => setState(() => index = v), destinations: const [NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'الرئيسية'), NavigationDestination(icon: Icon(Icons.people_outline), label: 'المرضى'), NavigationDestination(icon: Icon(Icons.calendar_month_outlined), label: 'المواعيد'), NavigationDestination(icon: Icon(Icons.healing_outlined), label: 'الجلسات'), NavigationDestination(icon: Icon(Icons.menu), label: 'المزيد')]),
  ));
}

class Dashboard extends StatelessWidget { const Dashboard({super.key}); @override Widget build(BuildContext c) => ListView(padding: const EdgeInsets.all(16), children: [
  _welcome(), const SizedBox(height: 12),
  GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2, mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 1.7, children: const [StatCard('المرضى', '245', Icons.people_outline), StatCard('مواعيد اليوم', '18', Icons.calendar_today), StatCard('جلسات اليوم', '12', Icons.healing), StatCard('المقبوضات', '85,000 ريال', Icons.payments_outlined)]),
  const SizedBox(height: 16), const SectionTitle('الوصول السريع'), Wrap(spacing: 10, runSpacing: 10, children: const [Quick('الفواتير', Icons.receipt_long), Quick('الباقات', Icons.inventory_2_outlined), Quick('الكادر الطبي', Icons.medical_services_outlined), Quick('الحسابات والخزينة', Icons.account_balance_wallet_outlined), Quick('المخزون', Icons.warehouse_outlined), Quick('التقارير', Icons.bar_chart_outlined)]),
]); }
Widget _welcome() => Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: navy, borderRadius: BorderRadius.circular(20)), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('مرحبًا بك 👋', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)), SizedBox(height: 6), Text('إدارة المرضى والمواعيد والجلسات والحسابات من مكان واحد.', style: TextStyle(color: Colors.white70))]); }
class StatCard extends StatelessWidget { final String a,b; final IconData i; const StatCard(this.a,this.b,this.i,{super.key}); @override Widget build(BuildContext c)=>Card(child: Padding(padding: const EdgeInsets.all(12), child: Row(children:[Icon(i,color:blue,size:28),const SizedBox(width:10),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.center,children:[Text(a,style:const TextStyle(color:Colors.grey)),Text(b,style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold))]))]))); }
class Quick extends StatelessWidget { final String t; final IconData i; const Quick(this.t,this.i,{super.key}); @override Widget build(BuildContext c)=>SizedBox(width:150,child:Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(children:[Icon(i,color:blue),const SizedBox(height:7),Text(t,textAlign:TextAlign.center)])))); }
class SectionTitle extends StatelessWidget { final String t; const SectionTitle(this.t,{super.key}); @override Widget build(BuildContext c)=>Padding(padding:const EdgeInsets.only(bottom:10),child:Text(t,style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold,color:navy))); }

class PatientsPage extends StatefulWidget { const PatientsPage({super.key}); @override State<PatientsPage> createState()=>_PatientsState(); }
class _PatientsState extends State<PatientsPage> { final list=<Map<String,String>>[{'no':'PT-0001','name':'أحمد محمد','phone':'770000000','service':'علاج طبيعي'},{'no':'PT-0002','name':'محمد علي','phone':'733000000','service':'تأهيل عصبي'}]; final q=TextEditingController(); @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[Row(children:[const Expanded(child:SectionTitle('المرضى والملفات')),FilledButton.icon(onPressed:()=>_form(c),icon:const Icon(Icons.add),label:const Text('مريض جديد'))]),TextField(controller:q,onChanged:(_)=>setState((){}),decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'ابحث بالاسم أو الهاتف أو رقم الملف',border:OutlineInputBorder())),const SizedBox(height:12),...list.where((x)=>q.text.isEmpty||x.values.any((v)=>v.contains(q.text))).map((p)=>Card(child:ListTile(leading:CircleAvatar(backgroundColor:blue,child:Text(p['no']!.split('-').last)),title:Text(p['name']!),subtitle:Text('${p['no']} • ${p['phone']}\n${p['service']}'),isThreeLine:true,trailing:const Icon(Icons.chevron_left))))]);
void _form(BuildContext c){final name=TextEditingController();final phone=TextEditingController();DateTime? dob;showDialog(context:c,builder:(_)=>StatefulBuilder(builder:(ctx,set)=>AlertDialog(title:const Text('إضافة مريض'),content:SingleChildScrollView(child:Column(children:[TextField(controller:name,decoration:const InputDecoration(labelText:'الاسم الثلاثي')),TextField(controller:phone,keyboardType:TextInputType.phone,decoration:const InputDecoration(labelText:'رقم الهاتف')),const SizedBox(height:10),OutlinedButton.icon(onPressed:()async{final d=await showDatePicker(context:ctx,firstDate:DateTime(1900),lastDate:DateTime.now(),initialDate:DateTime(2000),locale:const Locale('ar'));if(d!=null)set(()=>dob=d);},icon:const Icon(Icons.calendar_month),label:Text(dob==null?'تاريخ الميلاد: DD/MM/YYYY':'تاريخ الميلاد: ${DateFormat('dd/MM/yyyy').format(dob!)}'))])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('إلغاء')),FilledButton(onPressed:(){if(name.text.trim().isEmpty)return;this.setState(()=>list.insert(0,{'no':'PT-${(list.length+1).toString().padLeft(4,'0')}','name':name.text.trim(),'phone':phone.text.trim(),'service':'غير محدد'}));Navigator.pop(ctx);},child:const Text('حفظ'))]));}
}

class AppointmentsPage extends StatelessWidget { const AppointmentsPage({super.key}); @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[Row(children:[const Expanded(child:SectionTitle('المواعيد')),FilledButton.icon(onPressed:()=>showDatePicker(context:c,firstDate:DateTime.now(),lastDate:DateTime.now().add(const Duration(days:365)),initialDate:DateTime.now()),icon:const Icon(Icons.add),label:const Text('موعد'))]),const Card(child:ListTile(leading:CircleAvatar(child:Icon(Icons.person)),title:Text('أحمد محمد – جلسة علاج طبيعي'),subtitle:Text('16/09/2026 • 10:00 • أخصائي العلاج الطبيعي'),trailing:Chip(label:Text('مؤكد')))),const Card(child:ListTile(leading:CircleAvatar(child:Icon(Icons.person)),title:Text('محمد علي – متابعة'),subtitle:Text('16/09/2026 • 12:00 • عيادة المخ والأعصاب'),trailing:Chip(label:Text('محجوز'))))]); }
class SessionsPage extends StatelessWidget { const SessionsPage({super.key}); @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[const SectionTitle('الجلسات العلاجية'),FilledButton.icon(onPressed:(){},icon:const Icon(Icons.add),label:const Text('تسجيل جلسة')),const SizedBox(height:10),const Card(child:ListTile(title:Text('أحمد محمد'),subtitle:Text('علاج طبيعي • 16/09/2026'),trailing:Text('جلسة مكتملة')))]); }
class MorePage extends StatelessWidget { const MorePage({super.key}); @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[const SectionTitle('المزيد'),...['الفواتير والقبض','كشف الحساب','الباقات العلاجية','الأطباء والمعالجون','دليل الخدمات والأسعار','الحسابات والخزينة','المخزون والجرد','الرسائل وWhatsApp/SMS','التقارير والتصدير','الإعدادات','النسخ الاحتياطي','الترخيص والاشتراك'].map((x)=>Card(child:ListTile(title:Text(x),trailing:const Icon(Icons.chevron_left),onTap:(){}))) ]); }
