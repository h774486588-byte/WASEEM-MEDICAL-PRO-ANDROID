package com.waseem.medical;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.*;

public class DB extends SQLiteOpenHelper {
    private final Context ctx;
    public DB(Context c){super(c,"waseem_medical.db",null,3);ctx=c.getApplicationContext();}
    public void onCreate(SQLiteDatabase d){
        d.execSQL("CREATE TABLE patients(id INTEGER PRIMARY KEY AUTOINCREMENT,file_no TEXT UNIQUE,name TEXT NOT NULL,phone TEXT,address TEXT,gender TEXT,birth TEXT,case_name TEXT,service TEXT,department TEXT,notes TEXT,created_at TEXT)");
        d.execSQL("CREATE TABLE services(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,department TEXT,price REAL,active INTEGER DEFAULT 1)");
        d.execSQL("CREATE TABLE cases(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,category TEXT,description TEXT,active INTEGER DEFAULT 1)");
        d.execSQL("CREATE TABLE appointments(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER,date TEXT,time TEXT,doctor TEXT,service TEXT,status TEXT,notes TEXT)");
        d.execSQL("CREATE TABLE sessions(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER,date TEXT,service TEXT,doctor TEXT,notes TEXT,package_id INTEGER DEFAULT 0)");
        d.execSQL("CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER,date TEXT,total REAL,paid REAL,method TEXT,notes TEXT)");
        d.execSQL("CREATE TABLE invoice_items(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER,service TEXT,qty INTEGER,price REAL)");
        d.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER,date TEXT,amount REAL,method TEXT,notes TEXT)");
        d.execSQL("CREATE TABLE packages(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER,name TEXT,total_sessions INTEGER,used_sessions INTEGER DEFAULT 0,price REAL,paid REAL,start_date TEXT,end_date TEXT,status TEXT)");
        d.execSQL("CREATE TABLE inventory(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,barcode TEXT,unit TEXT,qty REAL,cost REAL,sale REAL,min_qty REAL,expiry TEXT)");
        d.execSQL("CREATE TABLE staff(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,role TEXT,specialty TEXT,department TEXT,phone TEXT,salary REAL,percent REAL,active INTEGER DEFAULT 1)");
        d.execSQL("CREATE TABLE cash(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT,type TEXT,amount REAL,method TEXT,description TEXT,user_name TEXT)");
        d.execSQL("CREATE TABLE audit(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT,user_name TEXT,action TEXT,details TEXT)");
        d.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY,v TEXT)");
        seed(d);
    }
    void seed(SQLiteDatabase d){
        String[][] services={{"العلاج الطبيعي","قسم الرجال","1500"},{"تأهيل الأطفال","قسم الأطفال","2000"},{"جلسة تغذية علاجية","التغذية العلاجية","3000"},{"جلسة حجامة علاجية","الحجامة والمساج","2500"},{"مساج علاجي","الحجامة والمساج","2500"},{"جلسة صالة رياضية","الصالة الرياضية","1500"},{"تأهيل عصبي","قسم الرجال","2500"}};
        for(String[] x:services)d.execSQL("INSERT INTO services(name,department,price) VALUES(?,?,?)",x);
        String[][] cases={{"تأخر النمو","الأطفال"},{"الشلل الدماغي","الأطفال"},{"آلام الظهر","الرجال"},{"التأهيل العصبي","الرجال"},{"الجلطات والسكتات","المخ والأعصاب"},{"الصرع والتشنجات","المخ والأعصاب"},{"الصداع النصفي المزمن","المخ والأعصاب"},{"التهاب الأعصاب والتنميل","المخ والأعصاب"},{"عرق النسا وانضغاط الأعصاب","المخ والأعصاب"},{"الدوخة وعدم الاتزان","المخ والأعصاب"},{"الشلل الرعاش وباركنسون","المخ والأعصاب"},{"الزهايمر وضعف الذاكرة","المخ والأعصاب"},{"شلل العصب السابع","المخ والأعصاب"},{"اضطرابات الجهاز الهضمي","التغذية العلاجية"},{"إنقاص أو زيادة الوزن","التغذية العلاجية"}};
        for(String[] x:cases)d.execSQL("INSERT INTO cases(name,category) VALUES(?,?)",x);
        put(d,"center_name","المركز الأول للعلاج الطبيعي والتأهيل"); put(d,"branch","فرع دمت"); put(d,"phone","770237644 / 733844808 / 713651708"); put(d,"address","محافظة الضالع - مدينة دمت - شارع الدلة (المتفرع من فرزة يريم) - جوار صالة عامر ومحلات صالح خنداد - أمام محلات الموتى لمواد البناء"); put(d,"tagline","خطوتك الأولى نحو صحة أفضل"); put(d,"developer","وسيم الفرح لخدمات التقنية والأنظمة - 774486588");
    }
    void put(SQLiteDatabase d,String k,String v){d.execSQL("INSERT OR REPLACE INTO settings(k,v) VALUES(?,?)",new Object[]{k,v});}
    public void onUpgrade(SQLiteDatabase d,int a,int b){
        if(a<3){ try{d.execSQL("ALTER TABLE patients ADD COLUMN gender TEXT");}catch(Exception ignored){} try{d.execSQL("CREATE TABLE IF NOT EXISTS cases(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,category TEXT,description TEXT,active INTEGER DEFAULT 1)");}catch(Exception ignored){} }
    }
    public long addPatient(ContentValues v){return getWritableDatabase().insert("patients",null,v);}
    public Cursor patients(String q){return getReadableDatabase().rawQuery("SELECT * FROM patients WHERE name LIKE ? OR phone LIKE ? OR file_no LIKE ? ORDER BY id DESC",new String[]{"%"+q+"%","%"+q+"%","%"+q+"%"});}
    public Cursor all(String table){return getReadableDatabase().rawQuery("SELECT * FROM "+table+" ORDER BY id DESC",null);}
    public Cursor query(String sql,String[] args){return getReadableDatabase().rawQuery(sql,args);}
    public long insert(String table,ContentValues v){return getWritableDatabase().insert(table,null,v);}
    public int update(String table,ContentValues v,String where,String[] args){return getWritableDatabase().update(table,v,where,args);}
    public void exec(String sql,String[] args){getWritableDatabase().execSQL(sql,args);}
    public String setting(String k){Cursor c=query("SELECT v FROM settings WHERE k=?",new String[]{k});String v="";if(c.moveToFirst())v=c.getString(0);c.close();return v;}
    public void log(String action,String details){ContentValues v=new ContentValues();v.put("date",now());v.put("user_name","المستخدم");v.put("action",action);v.put("details",details);insert("audit",v);}
    public String exportBackup(){
        try{
            File dir=ctx.getExternalFilesDir(null); if(dir==null)dir=ctx.getFilesDir(); if(!dir.exists())dir.mkdirs();
            File f=new File(dir,"waseem_medical_backup_"+System.currentTimeMillis()+".txt"); FileWriter w=new FileWriter(f);
            String[] tables={"patients","appointments","sessions","invoices","payments","packages","inventory","staff","cash"};
            for(String t:tables){w.write("\n=== "+t+" ===\n");Cursor c=all(t);int n=c.getColumnCount();while(c.moveToNext()){for(int i=0;i<n;i++){w.write(c.getColumnName(i)+"="+c.getString(i)+" | ");}w.write("\n");}c.close();}w.close();return f.getAbsolutePath();
        }catch(Exception e){return "تعذر إنشاء النسخة: "+e.getMessage();}
    }
    public static String now(){return new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date());}
    public static String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
}
