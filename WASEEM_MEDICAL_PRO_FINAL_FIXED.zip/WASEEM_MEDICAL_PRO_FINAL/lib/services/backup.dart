import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

class BackupService {
  static Future<File> createBackup(Map<String,List<Map<String,dynamic>>> data) async {
    final dir=await getApplicationDocumentsDirectory(); final file=File('${dir.path}/waseem_medical_backup_${DateTime.now().millisecondsSinceEpoch}.json');
    await file.writeAsString(const JsonEncoder.withIndent('  ').convert(data)); return file;
  }
  static Future<void> share(File file) async { await SharePlus.instance.share(ShareParams(files:[XFile(file.path)],text:'نسخة احتياطية من نظام وسيم ميديكال')); }
}
