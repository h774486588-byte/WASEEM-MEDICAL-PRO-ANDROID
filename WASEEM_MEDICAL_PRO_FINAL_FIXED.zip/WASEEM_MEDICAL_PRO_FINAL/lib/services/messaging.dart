import 'package:url_launcher/url_launcher.dart';

class MessagingService {
  static String template(String type, Map<String, String> values) {
    final name = values['name'] ?? '';
    final file = values['file'] ?? '';
    final date = values['date'] ?? '';
    final time = values['time'] ?? '';

    switch (type) {
      case 'appointment':
        return 'مرحبًا $name، نؤكد موعدكم في وسيم ميديكال بتاريخ $date الساعة $time. رقم الملف: $file.';
      case 'receipt':
        return 'مرحبًا $name، تم تسجيل سند قبض بالمبلغ ${values['amount'] ?? ''}. شكرًا لكم.';
      case 'package':
        return 'مرحبًا $name، تبقت لكم ${values['remaining'] ?? ''} جلسات من الباقة.';
      case 'registration':
      default:
        return 'مرحبًا $name، تم تسجيل ملفكم الطبي في وسيم ميديكال. رقم الملف: $file.';
    }
  }

  static Future<void> whatsapp(String phone, String message) async {
    final cleanPhone = _normalizeYemenPhone(phone);
    if (cleanPhone.isEmpty) return;

    final uri = Uri.parse(
      'https://wa.me/$cleanPhone?text=${Uri.encodeComponent(message)}',
    );
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  static Future<void> sms(String phone, String message) async {
    final cleanPhone = phone.replaceAll(RegExp(r'[^0-9+]'), '');
    if (cleanPhone.isEmpty) return;

    final uri = Uri(
      scheme: 'sms',
      path: cleanPhone,
      queryParameters: <String, String>{'body': message},
    );
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  static String _normalizeYemenPhone(String phone) {
    var value = phone.trim().replaceAll(RegExp(r'[^0-9+]'), '');
    if (value.startsWith('+')) value = value.substring(1);
    if (value.startsWith('00967')) value = value.substring(2);

    // أرقام اليمن المحلية مثل 77xxxxxxx تتحول إلى 96777xxxxxxx.
    if (value.startsWith('0') && value.length == 10) {
      value = value.substring(1);
    }
    if (value.length == 9 && value.startsWith('7')) {
      value = '967$value';
    }
    return value;
  }
}
