import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/app_provider.dart';
import '../services/messaging.dart';

class AddPatientScreen extends StatefulWidget {
  const AddPatientScreen({super.key});

  @override
  State<AddPatientScreen> createState() => _AddPatientScreenState();
}

class _AddPatientScreenState extends State<AddPatientScreen> {
  final _formKey = GlobalKey<FormState>();

  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _ageController = TextEditingController();
  final _addressController = TextEditingController();
  final _serviceController =
      TextEditingController(text: 'كشف/استشارة');
  final _doctorController = TextEditingController();
  final _notesController = TextEditingController();

  String _gender = 'ذكر';
  String _department = 'الأطفال';
  bool _prepareMessage = false;
  bool _saving = false;

  static const List<String> _genders = <String>['ذكر', 'أنثى'];

  static const List<String> _departments = <String>[
    'الأطفال',
    'النساء',
    'الرجال',
    'الحجامة والمساج',
    'الصالة الرياضية',
    'التغذية العلاجية',
    'المخ والأعصاب',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('إضافة مريض جديد'),
      ),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(14, 14, 14, 24),
            keyboardDismissBehavior:
                ScrollViewKeyboardDismissBehavior.onDrag,
            children: <Widget>[
              _field(
                controller: _nameController,
                label: 'الاسم الكامل',
                required: true,
              ),
              _field(
                controller: _phoneController,
                label: 'رقم الهاتف',
                keyboardType: TextInputType.phone,
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Expanded(
                    child: _field(
                      controller: _ageController,
                      label: 'العمر',
                      keyboardType: TextInputType.number,
                      validator: _validateAge,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: DropdownButtonFormField<String>(
                      value: _gender,
                      isExpanded: true,
                      decoration: const InputDecoration(
                        labelText: 'الجنس',
                      ),
                      items: _genders
                          .map(
                            (String value) =>
                                DropdownMenuItem<String>(
                              value: value,
                              child: Text(value),
                            ),
                          )
                          .toList(),
                      onChanged: _saving
                          ? null
                          : (String? value) {
                              if (value == null) return;
                              setState(() => _gender = value);
                            },
                    ),
                  ),
                ],
              ),
              _field(
                controller: _addressController,
                label: 'العنوان',
              ),
              DropdownButtonFormField<String>(
                value: _department,
                isExpanded: true,
                decoration: const InputDecoration(
                  labelText: 'القسم',
                ),
                items: _departments
                    .map(
                      (String value) =>
                          DropdownMenuItem<String>(
                        value: value,
                        child: Text(value),
                      ),
                    )
                    .toList(),
                onChanged: _saving
                    ? null
                    : (String? value) {
                        if (value == null) return;
                        setState(() => _department = value);
                      },
              ),
              const SizedBox(height: 12),
              _field(
                controller: _serviceController,
                label: 'الخدمة',
              ),
              _field(
                controller: _doctorController,
                label: 'الطبيب/الأخصائي',
              ),
              _field(
                controller: _notesController,
                label: 'الملاحظات',
                maxLines: 4,
              ),
              const SizedBox(height: 4),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                value: _prepareMessage,
                onChanged: _saving
                    ? null
                    : (bool value) {
                        setState(() => _prepareMessage = value);
                      },
                title: const Text('تجهيز رسالة بعد الحفظ'),
                subtitle: const Text(
                  'تُفتح المحادثة في واتساب العادي بعد الحفظ.',
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                height: 50,
                child: FilledButton.icon(
                  onPressed: _saving ? null : _save,
                  icon: _saving
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                          ),
                        )
                      : const Icon(Icons.save),
                  label: Text(
                    _saving ? 'جارٍ الحفظ...' : 'حفظ المريض',
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String? _validateAge(String? value) {
    final text = value?.trim() ?? '';
    if (text.isEmpty) return null;

    final age = int.tryParse(text);
    if (age == null || age < 0 || age > 120) {
      return 'أدخل عمرًا صحيحًا من 0 إلى 120';
    }
    return null;
  }

  Future<void> _save() async {
    if (_saving) return;
    if (!_formKey.currentState!.validate()) return;

    final provider = context.read<AppProvider>();
    final patientName = _nameController.text.trim();
    final patientPhone = _phoneController.text.trim();
    final fileNo = provider.fileNo();

    setState(() => _saving = true);

    try {
      final data = <String, dynamic>{
        'file_no': fileNo,
        'name': patientName,
        'phone': patientPhone,
        'gender': _gender,
        'age': int.tryParse(_ageController.text.trim()),
        'address': _addressController.text.trim(),
        'case_type': '',
        'department': _department,
        'service': _serviceController.text.trim(),
        'doctor': _doctorController.text.trim(),
        'registered_at': DateTime.now().toIso8601String(),
        'notes': _notesController.text.trim(),
        'active': 1,
      };

      await provider.addPatient(data);

      if (!mounted) return;

      // نغلق شاشة التسجيل أولًا حتى لا تبقى الواجهة عالقة
      // إذا فتح واتساب خارجيًا.
      Navigator.of(context).pop();

      if (_prepareMessage && patientPhone.isNotEmpty) {
        final message = MessagingService.template(
          'registration',
          <String, String>{
            'name': patientName,
            'file': fileNo,
          },
        );

        try {
          await MessagingService.whatsapp(
            patientPhone,
            message,
          );
        } catch (_) {
          // فشل فتح واتساب لا يعني فشل تسجيل المريض.
        }
      }
    } catch (e) {
      if (!mounted) return;

      setState(() => _saving = false);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('تعذر حفظ المريض: $e'),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  Widget _field({
    required TextEditingController controller,
    required String label,
    bool required = false,
    TextInputType keyboardType = TextInputType.text,
    int maxLines = 1,
    String? Function(String?)? validator,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        maxLines: maxLines,
        textInputAction: maxLines > 1
            ? TextInputAction.newline
            : TextInputAction.next,
        decoration: InputDecoration(
          labelText: label,
          alignLabelWithHint: maxLines > 1,
        ),
        validator: validator ??
            (required
                ? (String? value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'هذا الحقل مطلوب';
                    }
                    return null;
                  }
                : null),
      ),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _ageController.dispose();
    _addressController.dispose();
    _serviceController.dispose();
    _doctorController.dispose();
    _notesController.dispose();
    super.dispose();
  }
}
