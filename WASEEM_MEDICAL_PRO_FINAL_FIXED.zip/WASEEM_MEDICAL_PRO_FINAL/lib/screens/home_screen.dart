import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_config.dart';
import '../providers/app_provider.dart';
import 'add_patient_screen.dart';
import 'module_screen.dart';
import 'patients_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<AppProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text(AppConfig.appName),
        actions: <Widget>[
          IconButton(
            onPressed: provider.toggleDark,
            icon: Icon(
              provider.darkMode ? Icons.light_mode : Icons.dark_mode,
            ),
            tooltip: 'الوضع الليلي',
          ),
          PopupMenuButton<String>(
            onSelected: (String value) {
              if (value == 'settings') {
                Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => const ModuleScreen(
                      title: 'الإعدادات',
                      type: 'settings',
                    ),
                  ),
                );
              }
            },
            itemBuilder: (_) => const <PopupMenuEntry<String>>[
              PopupMenuItem<String>(
                value: 'settings',
                child: Text('الإعدادات'),
              ),
            ],
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: provider.loadAll,
        child: ListView(
          padding: const EdgeInsets.all(12),
          children: <Widget>[
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: <Widget>[
                    const CircleAvatar(
                      radius: 28,
                      child: Icon(Icons.local_hospital),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          const Text(
                            'لوحة التحكم',
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text('الدعم ${AppConfig.supportPhone}'),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              childAspectRatio: 1.55,
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
              children: <Widget>[
                _stat('المرضى', provider.patients.length, Icons.people),
                _stat(
                  'مواعيد اليوم',
                  provider.appointments.length,
                  Icons.calendar_month,
                ),
                _stat(
                  'الجلسات',
                  provider.sessions.length,
                  Icons.accessibility_new,
                ),
                _stat(
                  'الفواتير',
                  provider.invoices.length,
                  Icons.receipt_long,
                ),
              ],
            ),
            const SizedBox(height: 14),
            _section('الوصول السريع'),
            _tile(context, 'المرضى', 'patients', Icons.people),
            _tile(context, 'المواعيد', 'appointments', Icons.calendar_month),
            _tile(
              context,
              'الجلسات والباقات',
              'sessions',
              Icons.event_available,
            ),
            _tile(
              context,
              'المحاسبة والصندوق',
              'accounting',
              Icons.account_balance_wallet,
            ),
            _tile(context, 'الكادر والموظفون', 'staff', Icons.badge),
            _tile(context, 'المخزون', 'inventory', Icons.inventory_2),
            _tile(context, 'التقارير', 'reports', Icons.analytics),
            _tile(context, 'مركز الرسائل', 'messages', Icons.message),
            _tile(context, 'الأقسام والخدمات', 'departments', Icons.category),
          ],
        ),
      ),
    );
  }

  Widget _stat(String title, int number, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: <Widget>[
            Icon(icon, size: 30),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(title),
                  Text(
                    '$number',
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _section(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Text(
        title,
        style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget _tile(
    BuildContext context,
    String title,
    String type,
    IconData icon,
  ) {
    return Card(
      child: ListTile(
        leading: CircleAvatar(child: Icon(icon)),
        title: Text(title),
        trailing: const Icon(Icons.chevron_left),
        onTap: () {
          Navigator.of(context).push(
            MaterialPageRoute<void>(
              builder: (_) => type == 'patients'
                  ? const PatientsScreen()
                  : ModuleScreen(title: title, type: type),
            ),
          );
        },
      ),
    );
  }
}
