import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/app_config.dart';
import 'core/theme.dart';
import 'providers/app_provider.dart';
import 'screens/splash_screen.dart';

void main() async { WidgetsFlutterBinding.ensureInitialized(); final p=AppProvider(); await p.init(); runApp(ChangeNotifierProvider.value(value:p,child:const WaseemMedicalApp())); }

class WaseemMedicalApp extends StatelessWidget {
  const WaseemMedicalApp({super.key});
  @override Widget build(BuildContext context){ final p=context.watch<AppProvider>(); return MaterialApp(debugShowCheckedModeBanner:false,title:AppConfig.appName,theme:AppTheme.light(),darkTheme:AppTheme.dark(),themeMode:p.darkMode?ThemeMode.dark:ThemeMode.light,home:const SplashScreen(),builder:(context,child)=>Directionality(textDirection:TextDirection.rtl,child:child??const SizedBox.shrink())); }
}
