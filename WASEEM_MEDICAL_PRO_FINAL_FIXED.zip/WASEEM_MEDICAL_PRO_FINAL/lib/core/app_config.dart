class AppConfig {
  static const appName = 'وسيم ميديكال';
  static const appNameEn = 'WASEEM MEDICAL PRO';
  static const supportPhone = '774486588';
  static const version = '1.0.0';
}
