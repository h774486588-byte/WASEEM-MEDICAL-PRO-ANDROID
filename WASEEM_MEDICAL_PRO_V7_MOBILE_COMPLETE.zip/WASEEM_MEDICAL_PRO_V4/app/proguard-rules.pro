# Waseem Medical Pro release rules
