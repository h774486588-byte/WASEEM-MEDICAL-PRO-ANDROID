# Waseem Medical Pro Backend

This Android release is local-first and API-ready. The production backend should expose authenticated REST endpoints for clinics, branches, users, licenses, patients, staff, services, appointments, sessions, invoices, payments, packages, inventory, reports and audit logs.

## Required production services
- HTTPS REST API
- PostgreSQL (recommended)
- JWT/session authentication with refresh tokens
- Argon2id password hashing
- Role-based access control
- Tenant isolation by clinic_id
- Rate limiting and audit logging
- Signed license validation
- Object storage for attachments and generated PDFs
- Scheduled notification worker for WhatsApp/SMS
- Google OAuth for Drive backup

No API key, OAuth secret, WhatsApp provider credential, SMS credential, or payment credential is embedded in this source code.
