# Owner Admin Dashboard Blueprint

Private web dashboard for the product owner.

Modules:
1. Clinics and branches
2. License IDs and subscription plans
3. 14-day trials
4. Expiry and renewal
5. Allowed devices
6. User/role management
7. Usage and audit logs
8. Backup health
9. Notification provider status
10. Support notes

The dashboard must authenticate separately from clinic users and never expose provider secrets to the Android client.
