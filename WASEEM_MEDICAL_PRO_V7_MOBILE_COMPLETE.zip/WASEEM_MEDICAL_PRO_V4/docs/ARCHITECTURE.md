# Architecture

Android client: local-first SQLite + UI + repository/service boundary.
Backend: authenticated multi-tenant API + PostgreSQL.
Owner dashboard: separate privileged application.
Integrations: WhatsApp/SMS, Google Drive, PDF/Excel export.

Clinic data is always scoped by clinic_id on the server. Sensitive provider credentials remain server-side.
