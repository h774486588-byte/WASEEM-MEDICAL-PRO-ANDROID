# Production Integrations

## WhatsApp/SMS
Use a server-side provider adapter. Templates must be editable and support variables such as {{patient_name}}, {{date}}, {{time}}, {{clinic_name}}. Never place provider tokens in the APK.

## Google Drive
Use Google OAuth 2.0. Store refresh tokens encrypted server-side. The Android app receives short-lived authorization/session data only.

## Licensing
The app identifies the clinic with Clinic ID + License ID. The backend validates plan, expiry and device allowance. Offline grace periods should be explicit and auditable.
