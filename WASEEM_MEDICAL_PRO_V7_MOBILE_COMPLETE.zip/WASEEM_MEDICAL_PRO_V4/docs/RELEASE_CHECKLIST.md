# Release Checklist

- [ ] Configure production API base URL
- [ ] Configure PostgreSQL and migrations
- [ ] Configure JWT/session security
- [ ] Configure WhatsApp/SMS provider
- [ ] Configure Google OAuth/Drive
- [ ] Configure owner dashboard
- [ ] Add signing keystore through GitHub Secrets
- [ ] Enable R8/ProGuard and verify mappings
- [ ] Test login, roles and tenant isolation
- [ ] Test patient, appointment, session, invoice, payment and statement flows
- [ ] Test backup/restore
- [ ] Test PDF/Excel export
- [ ] Test Android 8 through current supported Android
- [ ] Build signed AAB/APK
