package com.waseem.medical;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

public class DB extends SQLiteOpenHelper {
    public DB(Context c){super(c,"waseem_medical.db",null,1);}
    public void onCreate(SQLiteDatabase d){
        d.execSQL("CREATE TABLE patients(id INTEGER PRIMARY KEY AUTOINCREMENT, file_no TEXT UNIQUE, name TEXT NOT NULL, phone TEXT, address TEXT, gender TEXT, dob TEXT, condition TEXT, service TEXT, department TEXT, therapist TEXT, notes TEXT, created_at TEXT)");
        d.execSQL("CREATE TABLE staff(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,specialty TEXT,department TEXT,phone TEXT,pay_type TEXT,pay_value REAL,active INTEGER)");
        d.execSQL("CREATE TABLE services(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,department TEXT,price REAL,duration INTEGER,active INTEGER)");
        d.execSQL("CREATE TABLE appointments(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER,patient_name TEXT,therapist TEXT,date TEXT,time TEXT,status TEXT,notes TEXT)");
        d.execSQL("CREATE TABLE sessions(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER,patient_name TEXT,therapist TEXT,date TEXT,service TEXT,status TEXT,notes TEXT,price REAL)");
        d.execSQL("CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,number TEXT,patient_id INTEGER,patient_name TEXT,total REAL,discount REAL,paid REAL,method TEXT,status TEXT,date TEXT)");
        d.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER,patient_name TEXT,amount REAL,method TEXT,note TEXT,date TEXT)");
        d.execSQL("CREATE TABLE packages(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER,patient_name TEXT,name TEXT,total_sessions INTEGER,used_sessions INTEGER,price REAL,paid REAL,start_date TEXT,expiry_date TEXT,status TEXT)");
        d.execSQL("CREATE TABLE inventory(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,sku TEXT,quantity REAL,unit TEXT,cost REAL,min_qty REAL,active INTEGER)");
        d.execSQL("CREATE TABLE audit(id INTEGER PRIMARY KEY AUTOINCREMENT,user_name TEXT,action TEXT,details TEXT,date TEXT)");
        d.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY,v TEXT)");
        seed(d);
    }
    void seed(SQLiteDatabase d){
        putSetting(d,"center_name","المركز الأول للعلاج الطبيعي والتأهيل - دمت"); putSetting(d,"slogan","خطوتك الأولى نحو صحة أفضل"); putSetting(d,"phones","770237644 - 733844808 - 713651708"); putSetting(d,"address","محافظة الضالع - مدينة دمت - شارع الدلة (المتفرع من فرزة يريم) - جوار صالة عامر ومحلات صالح خنداد - أمام محلات الموتى لمواد البناء"); putSetting(d,"developer","وسيم الفرح لخدمات التقنية والأنظمة - 774486588");
        String[][] s={{"العلاج الطبيعي","العلاج الطبيعي",0,"60"},{"التأهيل العصبي","التأهيل",0,"60"},{"الحجامة","الحجامة والمساج",0,"45"},{"المساج العلاجي","الحجامة والمساج",0,"45"},{"التغذية العلاجية","التغذية",0,"30"},{"عيادة المخ والأعصاب","المخ والأعصاب",0,"30"}};
        for(String[] x:s)d.execSQL("INSERT INTO services(name,department,price,duration,active) VALUES(?,?,?,?,1)",new Object[]{x[0],x[1],Double.parseDouble(x[2].toString()),Integer.parseInt(x[3])});
        String[][] staff={{"الأخصائي الرئيسي","علاج طبيعي","العلاج الطبيعي","","جلسة","0"},{"أخصائي التغذية","تغذية علاجية","التغذية","","جلسة","0"},{"طبيب المخ والأعصاب","مخ وأعصاب","المخ والأعصاب","","نسبة","0"}};
        for(String[] x:staff)d.execSQL("INSERT INTO staff(name,specialty,department,phone,pay_type,pay_value,active) VALUES(?,?,?,?,?,?,1)",new Object[]{x[0],x[1],x[2],x[3],x[4],Double.parseDouble(x[5])});
    }
    void putSetting(SQLiteDatabase d,String k,String v){d.execSQL("INSERT OR REPLACE INTO settings(k,v) VALUES(?,?)",new Object[]{k,v});}
    public String setting(String k,String def){Cursor c=getReadableDatabase().rawQuery("SELECT v FROM settings WHERE k=?",new String[]{k}); try{return c.moveToFirst()?c.getString(0):def;}finally{c.close();}}
    public void set(String k,String v){getWritableDatabase().execSQL("INSERT OR REPLACE INTO settings(k,v) VALUES(?,?)",new Object[]{k,v});}
    public long addPatient(String name,String phone,String address,String gender,String dob,String condition,String service,String dept,String therapist,String notes){
        String no="P"+String.format(Locale.US,"%06d",count("patients")+1); ContentValues v=new ContentValues(); v.put("file_no",no);v.put("name",name);v.put("phone",phone);v.put("address",address);v.put("gender",gender);v.put("dob",dob);v.put("condition",condition);v.put("service",service);v.put("department",dept);v.put("therapist",therapist);v.put("notes",notes);v.put("created_at",now()); long id=getWritableDatabase().insert("patients",null,v); audit("تسجيل مريض","ملف "+no+" - "+name); return id;
    }
    public long addAppointment(long pid,String pn,String therapist,String date,String time,String status,String notes){ContentValues v=new ContentValues();v.put("patient_id",pid);v.put("patient_name",pn);v.put("therapist",therapist);v.put("date",date);v.put("time",time);v.put("status",status);v.put("notes",notes);long id=getWritableDatabase().insert("appointments",null,v);audit("حجز موعد",pn+" - "+date+" "+time);return id;}
    public long addSession(long pid,String pn,String therapist,String date,String service,String status,String notes,double price){ContentValues v=new ContentValues();v.put("patient_id",pid);v.put("patient_name",pn);v.put("therapist",therapist);v.put("date",date);v.put("service",service);v.put("status",status);v.put("notes",notes);v.put("price",price);long id=getWritableDatabase().insert("sessions",null,v);audit("تسجيل جلسة",pn+" - "+service);return id;}
    public long addPayment(long pid,String pn,double amount,String method,String note){ContentValues v=new ContentValues();v.put("patient_id",pid);v.put("patient_name",pn);v.put("amount",amount);v.put("method",method);v.put("note",note);v.put("date",now());long id=getWritableDatabase().insert("payments",null,v);audit("تسجيل قبض",pn+" - "+amount);return id;}
    public long addInvoice(String num,long pid,String pn,double total,double disc,double paid,String method){ContentValues v=new ContentValues();v.put("number",num);v.put("patient_id",pid);v.put("patient_name",pn);v.put("total",total);v.put("discount",disc);v.put("paid",paid);v.put("method",method);v.put("status",paid>=total-disc?"مسدد":"متبقي");v.put("date",now());long id=getWritableDatabase().insert("invoices",null,v);audit("إصدار فاتورة",num+" - "+pn);return id;}
    public int count(String table){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+table,null);try{c.moveToFirst();return c.getInt(0);}finally{c.close();}}
    public double sum(String table,String col){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM("+col+"),0) FROM "+table,null);try{c.moveToFirst();return c.getDouble(0);}finally{c.close();}}
    public Cursor query(String sql,String[] args){return getReadableDatabase().rawQuery(sql,args);}
    public void audit(String a,String b){ContentValues v=new ContentValues();v.put("user_name","مدير المركز");v.put("action",a);v.put("details",b);v.put("date",now());getWritableDatabase().insert("audit",null,v);}
    public String now(){return new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date());}
    public void onUpgrade(SQLiteDatabase d,int o,int n){}
}
