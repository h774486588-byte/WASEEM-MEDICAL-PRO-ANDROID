# نظام وسيم الطبي PRO

منصة SaaS لإدارة المراكز الطبية والعيادات والعلاج الطبيعي والتأهيل.

## المكونات
- `mobile/` تطبيق Flutter RTL للأندرويد والأجهزة اللوحية.
- `backend/` هيكل Laravel REST API + PostgreSQL.
- `docs/` وثائق النطاق، قاعدة البيانات، وواجهات API.

## بيانات التجربة
- المستخدم: `admin`
- كلمة المرور: `1234`

> هذه النسخة هي قاعدة مشروع جديدة ومنظمة. التكاملات الإنتاجية (بوابة WhatsApp/SMS، Google OAuth/Drive، الدفع الإلكتروني، الاستضافة) تحتاج مفاتيح وبيئة تشغيل حقيقية ولا يتم تضمين أسرارها داخل المستودع.

## تشغيل تطبيق Flutter
```bash
cd mobile
flutter pub get
flutter run
```

## تشغيل Backend
أنشئ مشروع Laravel 11/12 جديدًا أو انسخ ملفات `backend/` فوق مشروع Laravel نظيف، ثم:
```bash
composer install
cp .env.example .env
php artisan key:generate
php artisan migrate --seed
php artisan serve
```

## الحسابات والصلاحيات
owner, manager, reception, therapist, accountant, inventory

## المبدأ
كل سجل تشغيلي مرتبط بالمركز `clinic_id` والمستخدم والتاريخ، مع Audit Log للعمليات الحساسة.
