<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\PatientController;
use App\Http\Controllers\Api\AppointmentController;
use App\Http\Controllers\Api\SessionController;
use App\Http\Controllers\Api\EmployeeController;
use App\Http\Controllers\Api\AttendanceController;
use App\Http\Controllers\Api\PayrollController;
use App\Http\Controllers\Api\MessageController;

Route::prefix('v1')->group(function () {
    Route::post('/auth/login', [AuthController::class, 'login']);
    Route::middleware('auth:sanctum')->group(function () {
        Route::get('/me', [AuthController::class, 'me']);
        Route::apiResource('patients', PatientController::class);
        Route::apiResource('appointments', AppointmentController::class)->except(['show']);
        Route::put('/appointments/{appointment}/status', [AppointmentController::class, 'status']);
        Route::apiResource('sessions', SessionController::class)->except(['show']);
        Route::apiResource('employees', EmployeeController::class);
        Route::get('/attendance', [AttendanceController::class, 'index']);
        Route::post('/attendance', [AttendanceController::class, 'store']);
        Route::apiResource('payroll', PayrollController::class)->only(['index','store']);
        Route::apiResource('messages', MessageController::class)->only(['index','store']);
    });
});
