<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Session extends Model { protected $fillable=['clinic_id','patient_id','staff_id','service_id','package_id','session_date','status','notes','price']; protected $casts=['session_date'=>'date','price'=>'decimal:2']; }
