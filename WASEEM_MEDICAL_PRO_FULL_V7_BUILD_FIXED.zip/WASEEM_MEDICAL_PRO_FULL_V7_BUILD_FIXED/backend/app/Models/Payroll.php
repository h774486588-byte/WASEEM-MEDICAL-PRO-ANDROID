<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model; use App\Models\Employee;
class Payroll extends Model { public function employee(){ return $this->belongsTo(Employee::class); } protected $fillable=['clinic_id','employee_id','period','base_salary','deductions','bonuses','net_salary','paid_amount','balance','paid_at','notes']; protected $casts=['base_salary'=>'decimal:2','deductions'=>'decimal:2','bonuses'=>'decimal:2','net_salary'=>'decimal:2','paid_amount'=>'decimal:2','balance'=>'decimal:2','paid_at'=>'date']; }
