<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class EmployeeTransaction extends Model { protected $fillable=['clinic_id','employee_id','transaction_date','type','amount','reference','description']; protected $casts=['transaction_date'=>'date','amount'=>'decimal:2']; }
