<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Employee extends Model { protected $fillable=['clinic_id','name','role','specialty','phone','base_salary','default_deductions','active']; protected $casts=['base_salary'=>'decimal:2','default_deductions'=>'decimal:2','active'=>'boolean']; }
