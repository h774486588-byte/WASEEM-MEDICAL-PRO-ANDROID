<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class MessageLog extends Model { protected $fillable=['clinic_id','user_id','channel','recipient','template','message','status','sent_at','error']; protected $casts=['sent_at'=>'datetime']; }
