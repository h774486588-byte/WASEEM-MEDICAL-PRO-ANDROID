<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Appointment extends Model { protected $fillable=['clinic_id','patient_id','staff_id','service_id','starts_at','ends_at','status','notes']; protected $casts=['starts_at'=>'datetime','ends_at'=>'datetime']; }
