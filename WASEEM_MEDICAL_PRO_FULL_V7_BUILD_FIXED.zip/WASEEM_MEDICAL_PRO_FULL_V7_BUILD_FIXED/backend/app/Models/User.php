<?php
namespace App\Models;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Sanctum\HasApiTokens;
class User extends Authenticatable { use HasApiTokens; protected $fillable=['clinic_id','name','username','password','role']; protected $hidden=['password','remember_token']; protected $casts=['password'=>'hashed']; }
