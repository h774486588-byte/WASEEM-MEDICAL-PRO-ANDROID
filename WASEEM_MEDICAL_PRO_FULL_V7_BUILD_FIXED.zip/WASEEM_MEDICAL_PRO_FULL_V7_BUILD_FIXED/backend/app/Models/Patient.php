<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Patient extends Model { use SoftDeletes; protected $fillable=['clinic_id','file_no','name','phone','gender','birth_date','address','condition','department_id','service_id','staff_id','source','notes']; protected $casts=['birth_date'=>'date']; }
