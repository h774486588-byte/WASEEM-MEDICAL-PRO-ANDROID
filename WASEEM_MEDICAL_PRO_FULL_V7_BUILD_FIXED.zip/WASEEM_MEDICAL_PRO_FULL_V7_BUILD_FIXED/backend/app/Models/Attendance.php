<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Attendance extends Model { protected $fillable=['clinic_id','employee_id','attendance_date','status','check_in','check_out','notes']; protected $casts=['attendance_date'=>'date']; }
