<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller; use App\Models\Patient; use Illuminate\Http\Request;
class PatientController extends Controller {
 public function index(Request $r){$q=Patient::where('clinic_id',$r->user()->clinic_id);if($r->filled('search'))$q->where(fn($x)=>$x->where('name','ilike','%'.$r->search.'%')->orWhere('phone','ilike','%'.$r->search.'%')->orWhere('file_no',$r->search));return ['data'=>$q->latest()->paginate(25)];}
 public function store(Request $r){$d=$r->validate(['name'=>'required|string|max:180','phone'=>'nullable|string|max:30','gender'=>'nullable|string|max:20','birth_date'=>'nullable|date','address'=>'nullable|string','condition'=>'nullable|string','notes'=>'nullable|string']);$d['clinic_id']=$r->user()->clinic_id;$d['file_no']='PT-'.str_pad((string)(Patient::where('clinic_id',$d['clinic_id'])->count()+1),6,'0',STR_PAD_LEFT);return ['data'=>Patient::create($d),'message'=>'تم تسجيل المريض'];}
 public function show(Request $r,Patient $patient){abort_unless($patient->clinic_id===$r->user()->clinic_id,404);return ['data'=>$patient];}
 public function update(Request $r,Patient $patient){abort_unless($patient->clinic_id===$r->user()->clinic_id,404);$patient->update($r->validate(['name'=>'sometimes|string|max:180','phone'=>'nullable|string|max:30','gender'=>'nullable|string|max:20','birth_date'=>'nullable|date','address'=>'nullable|string','condition'=>'nullable|string','notes'=>'nullable|string']));return ['data'=>$patient];}
 public function destroy(Request $r,Patient $patient){abort_unless($patient->clinic_id===$r->user()->clinic_id,404);$patient->delete();return ['message'=>'تم حذف السجل'];}
}
