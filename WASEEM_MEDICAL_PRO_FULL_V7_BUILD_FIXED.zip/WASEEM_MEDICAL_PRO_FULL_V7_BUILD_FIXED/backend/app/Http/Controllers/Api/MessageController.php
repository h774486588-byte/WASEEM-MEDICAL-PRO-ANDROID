<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller; use App\Models\MessageLog; use Illuminate\Http\Request;
class MessageController extends Controller {
 public function index(Request $r){ return MessageLog::where('clinic_id',$r->user()->clinic_id)->latest()->paginate(50); }
 public function store(Request $r){ $data=$r->validate(['channel'=>'required|in:whatsapp,sms','recipient'=>'required|string|max:50','template'=>'nullable|string|max:100','message'=>'required|string']); $data['clinic_id']=$r->user()->clinic_id; $data['user_id']=$r->user()->id; return response()->json(MessageLog::create($data),202); }
}
