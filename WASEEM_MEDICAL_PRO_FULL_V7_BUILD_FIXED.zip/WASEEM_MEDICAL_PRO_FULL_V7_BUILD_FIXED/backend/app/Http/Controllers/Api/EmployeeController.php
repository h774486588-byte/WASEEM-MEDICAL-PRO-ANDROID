<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\Employee;
use Illuminate\Http\Request;
class EmployeeController extends Controller {
 public function index(Request $r){ return Employee::where('clinic_id',$r->user()->clinic_id)->orderBy('name')->paginate(50); }
 public function store(Request $r){ $data=$r->validate(['name'=>'required|string|max:255','role'=>'required|string|max:255','specialty'=>'nullable|string|max:255','phone'=>'nullable|string|max:30','base_salary'=>'nullable|numeric|min:0','default_deductions'=>'nullable|numeric|min:0']); $data['clinic_id']=$r->user()->clinic_id; return response()->json(Employee::create($data),201); }
 public function update(Request $r,Employee $employee){ abort_unless($employee->clinic_id===$r->user()->clinic_id,404); $data=$r->validate(['name'=>'sometimes|required|string|max:255','role'=>'sometimes|required|string|max:255','specialty'=>'nullable|string|max:255','phone'=>'nullable|string|max:30','base_salary'=>'nullable|numeric|min:0','default_deductions'=>'nullable|numeric|min:0','active'=>'nullable|boolean']); $employee->update($data); return $employee; }
 public function destroy(Request $r,Employee $employee){ abort_unless($employee->clinic_id===$r->user()->clinic_id,404); $employee->delete(); return response()->noContent(); }
}
