<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\Attendance;
use Illuminate\Http\Request;
class AttendanceController extends Controller {
 public function index(Request $r){ $q=Attendance::where('clinic_id',$r->user()->clinic_id); if($r->employee_id)$q->where('employee_id',$r->employee_id); if($r->date)$q->whereDate('attendance_date',$r->date); return $q->latest('attendance_date')->paginate(100); }
 public function store(Request $r){ $data=$r->validate(['employee_id'=>'required|exists:employees,id','attendance_date'=>'required|date','status'=>'required|in:present,absent,leave,late','check_in'=>'nullable','check_out'=>'nullable','notes'=>'nullable|string']); $employee=\App\Models\Employee::where('id',$data['employee_id'])->where('clinic_id',$r->user()->clinic_id)->firstOrFail(); $data['clinic_id']=$employee->clinic_id; $row=Attendance::updateOrCreate(['employee_id'=>$employee->id,'attendance_date'=>$data['attendance_date']],$data); return $row; }
}
