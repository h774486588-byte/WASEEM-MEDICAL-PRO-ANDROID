<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\Employee; use App\Models\Payroll; use Illuminate\Http\Request;
class PayrollController extends Controller {
 public function index(Request $r){ return Payroll::with('employee')->where('clinic_id',$r->user()->clinic_id)->latest()->paginate(50); }
 public function store(Request $r){ $data=$r->validate(['employee_id'=>'required|exists:employees,id','period'=>'required|date_format:Y-m','base_salary'=>'required|numeric|min:0','deductions'=>'nullable|numeric|min:0','bonuses'=>'nullable|numeric|min:0','paid_amount'=>'nullable|numeric|min:0','paid_at'=>'nullable|date','notes'=>'nullable|string']); $e=Employee::where('id',$data['employee_id'])->where('clinic_id',$r->user()->clinic_id)->firstOrFail(); $data['clinic_id']=$e->clinic_id; $data['deductions']=$data['deductions']??0; $data['bonuses']=$data['bonuses']??0; $data['paid_amount']=$data['paid_amount']??0; $data['net_salary']=$data['base_salary']+$data['bonuses']-$data['deductions']; $data['balance']=$data['net_salary']-$data['paid_amount']; return Payroll::updateOrCreate(['employee_id'=>$e->id,'period'=>$data['period']],$data); }
}
