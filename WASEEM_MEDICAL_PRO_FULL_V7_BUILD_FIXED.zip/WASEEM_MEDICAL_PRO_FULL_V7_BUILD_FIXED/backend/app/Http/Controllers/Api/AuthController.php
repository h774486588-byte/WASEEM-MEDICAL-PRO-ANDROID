<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
class AuthController extends Controller {
 public function login(Request $r){$data=$r->validate(['username'=>'required|string','password'=>'required|string']);$u=User::where('username',$data['username'])->first();if(!$u||!Hash::check($data['password'],$u->password))return response()->json(['message'=>'بيانات الدخول غير صحيحة'],422);return ['data'=>['token'=>$u->createToken('mobile')->plainTextToken,'user'=>$u]];}
 public function me(Request $r){return ['data'=>$r->user()];}
}
