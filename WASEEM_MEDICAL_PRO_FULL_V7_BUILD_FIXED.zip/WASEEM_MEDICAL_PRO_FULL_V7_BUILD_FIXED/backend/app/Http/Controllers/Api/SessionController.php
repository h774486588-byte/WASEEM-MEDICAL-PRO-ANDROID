<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller; use App\Models\Session; use Illuminate\Http\Request; use Illuminate\Support\Facades\DB;
class SessionController extends Controller {
 public function index(Request $r){return ['data'=>Session::where('clinic_id',$r->user()->clinic_id)->latest('session_date')->paginate(50)];}
 public function store(Request $r){$d=$r->validate(['patient_id'=>'required|integer','staff_id'=>'nullable|integer','service_id'=>'nullable|integer','package_id'=>'nullable|integer','session_date'=>'required|date','status'=>'required|in:completed,in_progress,cancelled','notes'=>'nullable|string','price'=>'nullable|numeric|min:0']);$d['clinic_id']=$r->user()->clinic_id;return ['data'=>DB::transaction(fn()=>Session::create($d)),'message'=>'تم تسجيل الجلسة'];}
 public function update(Request $r,Session $s){abort_unless($s->clinic_id===$r->user()->clinic_id,404);$s->update($r->validate(['status'=>'sometimes|in:completed,in_progress,cancelled','notes'=>'nullable|string','price'=>'nullable|numeric|min:0']));return ['data'=>$s];}
 public function destroy(Request $r,Session $s){abort_unless($s->clinic_id===$r->user()->clinic_id,404);$s->delete();return ['message'=>'تم حذف الجلسة'];}
}
