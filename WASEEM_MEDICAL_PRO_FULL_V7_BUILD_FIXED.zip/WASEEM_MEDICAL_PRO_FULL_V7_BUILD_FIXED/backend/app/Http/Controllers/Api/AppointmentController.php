<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller; use App\Models\Appointment; use Illuminate\Http\Request;
class AppointmentController extends Controller {
 public function index(Request $r){return ['data'=>Appointment::where('clinic_id',$r->user()->clinic_id)->latest('starts_at')->paginate(50)];}
 public function store(Request $r){$d=$r->validate(['patient_id'=>'required|integer','staff_id'=>'required|integer','service_id'=>'nullable|integer','starts_at'=>'required|date','ends_at'=>'required|date|after:starts_at','notes'=>'nullable|string']);$d['clinic_id']=$r->user()->clinic_id;$conflict=Appointment::where('clinic_id',$d['clinic_id'])->where('staff_id',$d['staff_id'])->whereIn('status',['booked','confirmed'])->where(function($q)use($d){$q->where('starts_at','<',$d['ends_at'])->where('ends_at','>',$d['starts_at']);})->exists();if($conflict)return response()->json(['message'=>'يوجد تعارض في موعد الطبيب/المعالج'],422);$d['status']='booked';return ['data'=>Appointment::create($d)];}
 public function update(Request $r,Appointment $a){abort_unless($a->clinic_id===$r->user()->clinic_id,404);$a->update($r->validate(['starts_at'=>'sometimes|date','ends_at'=>'sometimes|date','status'=>'sometimes|in:booked,confirmed,attended,cancelled,no_show','notes'=>'nullable|string']));return ['data'=>$a];}
 public function destroy(Request $r,Appointment $a){abort_unless($a->clinic_id===$r->user()->clinic_id,404);$a->delete();return ['message'=>'تم حذف الموعد'];}
 public function status(Request $r,Appointment $a){abort_unless($a->clinic_id===$r->user()->clinic_id,404);$a->update($r->validate(['status'=>'required|in:booked,confirmed,attended,cancelled,no_show']));return ['data'=>$a];}
}
