<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder; use App\Models\Clinic; use App\Models\User; use Illuminate\Support\Facades\Hash;
class DatabaseSeeder extends Seeder { public function run(){ $c=Clinic::firstOrCreate(['name'=>'المركز الأول للعلاج الطبيعي والتأهيل – دمت'],['phone'=>'770237644','address'=>'محافظة الضالع - مدينة دمت - شارع الدلة (المتفرع من فرزة يريم)']); User::firstOrCreate(['username'=>'admin'],['clinic_id'=>$c->id,'name'=>'مدير النظام','password'=>Hash::make('1234'),'role'=>'owner']); }}
