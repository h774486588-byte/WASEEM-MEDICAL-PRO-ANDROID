<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('employees', function (Blueprint $table) {
            $table->id(); $table->foreignId('clinic_id')->constrained()->cascadeOnDelete();
            $table->string('name'); $table->string('role'); $table->string('specialty')->nullable();
            $table->string('phone')->nullable(); $table->decimal('base_salary',12,2)->default(0);
            $table->decimal('default_deductions',12,2)->default(0); $table->boolean('active')->default(true); $table->timestamps();
            $table->index(['clinic_id','active']);
        });
    }
    public function down(): void { Schema::dropIfExists('employees'); }
};
