<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('attendances', function (Blueprint $table) {
            $table->id(); $table->foreignId('clinic_id')->constrained()->cascadeOnDelete();
            $table->foreignId('employee_id')->constrained('employees')->cascadeOnDelete();
            $table->date('attendance_date'); $table->enum('status',['present','absent','leave','late'])->default('present');
            $table->time('check_in')->nullable(); $table->time('check_out')->nullable(); $table->text('notes')->nullable(); $table->timestamps();
            $table->unique(['employee_id','attendance_date']);
        });
    }
    public function down(): void { Schema::dropIfExists('attendances'); }
};
