<?php
use Illuminate\Database\Migrations\Migration; use Illuminate\Database\Schema\Blueprint; use Illuminate\Support\Facades\Schema;
return new class extends Migration { public function up(){Schema::create('users',function(Blueprint $t){$t->id();$t->foreignId('clinic_id')->nullable()->constrained()->nullOnDelete();$t->string('name');$t->string('username')->unique();$t->string('password');$t->string('role')->default('reception');$t->rememberToken();$t->timestamps();});} public function down(){Schema::dropIfExists('users');}};
