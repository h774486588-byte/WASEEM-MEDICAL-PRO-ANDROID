<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('payrolls', function (Blueprint $table) {
            $table->id(); $table->foreignId('clinic_id')->constrained()->cascadeOnDelete();
            $table->foreignId('employee_id')->constrained('employees')->cascadeOnDelete();
            $table->string('period',7); $table->decimal('base_salary',12,2)->default(0); $table->decimal('deductions',12,2)->default(0);
            $table->decimal('bonuses',12,2)->default(0); $table->decimal('net_salary',12,2)->default(0);
            $table->decimal('paid_amount',12,2)->default(0); $table->decimal('balance',12,2)->default(0);
            $table->date('paid_at')->nullable(); $table->text('notes')->nullable(); $table->timestamps();
            $table->unique(['employee_id','period']);
        });
    }
    public function down(): void { Schema::dropIfExists('payrolls'); }
};
