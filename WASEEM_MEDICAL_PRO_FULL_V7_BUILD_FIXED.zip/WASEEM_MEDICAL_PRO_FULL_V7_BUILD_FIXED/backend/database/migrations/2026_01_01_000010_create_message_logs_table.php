<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('message_logs', function (Blueprint $table) {
            $table->id(); $table->foreignId('clinic_id')->constrained()->cascadeOnDelete();
            $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $table->string('channel'); $table->string('recipient'); $table->string('template')->nullable();
            $table->text('message'); $table->enum('status',['queued','sent','failed'])->default('queued'); $table->timestamp('sent_at')->nullable(); $table->text('error')->nullable(); $table->timestamps();
            $table->index(['clinic_id','channel','status']);
        });
    }
    public function down(): void { Schema::dropIfExists('message_logs'); }
};
