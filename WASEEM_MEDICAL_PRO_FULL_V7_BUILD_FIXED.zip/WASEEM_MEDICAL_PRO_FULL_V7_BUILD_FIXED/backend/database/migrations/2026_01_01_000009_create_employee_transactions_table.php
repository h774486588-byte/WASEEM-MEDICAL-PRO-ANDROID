<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('employee_transactions', function (Blueprint $table) {
            $table->id(); $table->foreignId('clinic_id')->constrained()->cascadeOnDelete();
            $table->foreignId('employee_id')->constrained('employees')->cascadeOnDelete();
            $table->date('transaction_date'); $table->enum('type',['salary','deduction','payment','bonus','other']);
            $table->decimal('amount',12,2); $table->string('reference')->nullable(); $table->text('description')->nullable(); $table->timestamps();
            $table->index(['employee_id','transaction_date']);
        });
    }
    public function down(): void { Schema::dropIfExists('employee_transactions'); }
};
