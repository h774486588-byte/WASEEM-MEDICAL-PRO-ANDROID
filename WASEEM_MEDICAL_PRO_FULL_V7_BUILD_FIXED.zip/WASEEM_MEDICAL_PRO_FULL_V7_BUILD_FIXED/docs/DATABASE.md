# الجداول المخطط لها

النواة الموجودة في هذا الإصدار: clinics, users, patients, appointments, sessions.

الإصدار التجاري الكامل يضيف: branches, licenses, departments, services, staff, medical_records, packages, package_sessions, invoices, invoice_items, payments, expenses, cash_transactions, products, inventory_transactions, notifications, message_templates, audit_logs, attachments, settings.

سبب فصلها: منع تعقيد النواة وإتاحة إضافة الوحدات بمعاملات واضحة دون تكرار منطق الأعمال.
