# API Contract v1

Base: `/api/v1`

- POST `/auth/login`
- GET `/me`
- GET/POST `/patients`
- GET/PUT/DELETE `/patients/{id}`
- GET/POST `/appointments`
- PUT `/appointments/{id}/status`
- GET/POST `/sessions`
- GET/POST `/packages`
- GET/POST `/services`
- GET/POST `/staff`
- GET/POST `/invoices`
- GET/POST `/payments`
- GET/POST `/expenses`
- GET/POST `/products`
- GET `/reports/dashboard`
- GET `/reports/patient/{id}/statement`
- GET/PUT `/settings`
- GET `/notifications`
- GET/POST `/message-templates`
- POST `/backups`
- GET `/license`

كل endpoint يعيد JSON موحدًا: `{data, message, meta}`.
