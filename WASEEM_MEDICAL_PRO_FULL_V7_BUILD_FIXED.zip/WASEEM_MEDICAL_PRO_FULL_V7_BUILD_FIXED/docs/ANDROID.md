# Android production checklist
- Camera permission for barcode scanning.
- Internet permission for API.
- File picker/storage access according to Android version.
- Notification permission for reminders.
- Bluetooth/network printer integration for thermal printers.
- Never store backend secrets in APK.
