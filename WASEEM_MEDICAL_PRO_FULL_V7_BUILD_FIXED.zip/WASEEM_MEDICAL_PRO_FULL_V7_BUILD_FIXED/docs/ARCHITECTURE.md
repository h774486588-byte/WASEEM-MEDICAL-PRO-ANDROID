# المعمارية

Flutter → Laravel REST API → PostgreSQL
                    ↘ Object Storage / Google Drive backup
                    ↘ WhatsApp/SMS provider

## قواعد مهمة
1. لا توجد أسرار API داخل تطبيق الهاتف.
2. كل طلب API مصادق عليه ومربوط بـ clinic_id.
3. العمليات المالية تستخدم معاملات قاعدة بيانات DB transactions.
4. حذف السجلات الحساسة يكون soft-delete حيث يلزم.
5. Audit log للإنشاء والتعديل والحذف وتغيير الصلاحيات والتراخيص.
