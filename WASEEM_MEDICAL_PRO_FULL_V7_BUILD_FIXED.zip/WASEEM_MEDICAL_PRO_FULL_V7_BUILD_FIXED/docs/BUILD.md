# بناء APK

يستخدم GitHub Actions مشروع Flutter نظيفًا مولدًا بواسطة `flutter create` لبناء Android، ثم ينسخ `lib/` و`pubspec.yaml` و`assets/` من التطبيق الفعلي. هذا يمنع أخطاء Gradle الناتجة عن مشاريع Android قديمة أو غير مدعومة.
