import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

const Color navy = Color(0xFF123A56);
const Color blue = Color(0xFF1E74B0);
const Color pageBackground = Color(0xFFF4F7FA);

void main() {
  runApp(const WaseemMedicalApp());
}

class WaseemMedicalApp extends StatefulWidget {
  const WaseemMedicalApp({super.key});

  @override
  State<WaseemMedicalApp> createState() => _WaseemMedicalAppState();
}

class _WaseemMedicalAppState extends State<WaseemMedicalApp> {
  ThemeMode themeMode = ThemeMode.light;

  void toggleTheme() {
    setState(() {
      themeMode = themeMode == ThemeMode.light ? ThemeMode.dark : ThemeMode.light;
    });
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData lightTheme = ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: blue),
      scaffoldBackgroundColor: pageBackground,
      fontFamily: 'sans-serif',
      inputDecorationTheme: const InputDecorationTheme(
        border: OutlineInputBorder(),
        filled: true,
        fillColor: Colors.white,
      ),
    );

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'نظام وسيم الطبي PRO',
      theme: lightTheme,
      darkTheme: ThemeData.dark(useMaterial3: true),
      themeMode: themeMode,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: LoginPage(onToggleTheme: toggleTheme),
    );
  }
}

class LoginPage extends StatefulWidget {
  final VoidCallback onToggleTheme;

  const LoginPage({super.key, required this.onToggleTheme});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController usernameController = TextEditingController(text: 'admin');
  final TextEditingController passwordController = TextEditingController(text: '1234');
  bool loading = false;
  bool obscurePassword = true;

  @override
  void dispose() {
    usernameController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  Future<void> login() async {
    FocusScope.of(context).unfocus();
    setState(() => loading = true);
    await Future<void>.delayed(const Duration(milliseconds: 300));

    final bool valid = usernameController.text.trim().toLowerCase() == 'admin' &&
        passwordController.text == '1234';

    if (!mounted) return;

    if (valid) {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setBool('logged_in', true);
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(builder: (_) => const MainShell()),
      );
    } else {
      setState(() => loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('اسم المستخدم أو كلمة المرور غير صحيحة')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          actions: [
            IconButton(
              tooltip: 'تبديل المظهر',
              onPressed: widget.onToggleTheme,
              icon: const Icon(Icons.brightness_6_outlined),
            ),
          ],
        ),
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(22),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 520),
                child: Column(
                  children: [
                    Container(
                      height: 120,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: navy,
                        borderRadius: BorderRadius.circular(28),
                      ),
                      child: const Center(
                        child: Icon(Icons.add, color: Colors.white, size: 68),
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'نظام وسيم الطبي PRO',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      'إدارة المراكز والعيادات والعلاج الطبيعي والتأهيل',
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 22),
                    Card(
                      elevation: 1,
                      child: Padding(
                        padding: const EdgeInsets.all(20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            const Text(
                              'بيانات الدخول',
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 16),
                            TextField(
                              controller: usernameController,
                              decoration: const InputDecoration(
                                labelText: 'اسم المستخدم',
                                prefixIcon: Icon(Icons.person_outline),
                              ),
                            ),
                            const SizedBox(height: 12),
                            TextField(
                              controller: passwordController,
                              obscureText: obscurePassword,
                              onSubmitted: (_) => login(),
                              decoration: InputDecoration(
                                labelText: 'كلمة المرور',
                                prefixIcon: const Icon(Icons.lock_outline),
                                suffixIcon: IconButton(
                                  onPressed: () => setState(() => obscurePassword = !obscurePassword),
                                  icon: Icon(
                                    obscurePassword ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(height: 18),
                            SizedBox(
                              height: 54,
                              child: FilledButton.icon(
                                onPressed: loading ? null : login,
                                icon: loading
                                    ? const SizedBox(
                                        width: 20,
                                        height: 20,
                                        child: CircularProgressIndicator(strokeWidth: 2),
                                      )
                                    : const Icon(Icons.login),
                                label: Text(loading ? 'جارٍ الدخول...' : 'دخول إلى النظام'),
                              ),
                            ),
                            const SizedBox(height: 10),
                            const Text(
                              'حساب التجربة: admin / 1234',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: Colors.grey),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'تطوير وتصميم: وسيم الفرح لخدمات التقنية والأنظمة\n774486588',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int selectedIndex = 0;

  final List<Widget> pages = const [
    DashboardPage(),
    PatientsPage(),
    AppointmentsPage(),
    SessionsPage(),
    MorePage(),
  ];

  Future<void> logout() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool('logged_in', false);
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute<void>(
        builder: (_) => LoginPage(onToggleTheme: () {}),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: navy,
          foregroundColor: Colors.white,
          title: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('نظام وسيم الطبي PRO', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              Text('المركز الأول للعلاج الطبيعي والتأهيل – دمت', style: TextStyle(fontSize: 10)),
            ],
          ),
          actions: [
            IconButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('لا توجد تنبيهات جديدة')),
                );
              },
              icon: const Icon(Icons.notifications_none),
            ),
            PopupMenuButton<String>(
              onSelected: (String value) {
                if (value == 'logout') logout();
              },
              itemBuilder: (BuildContext context) => const [
                PopupMenuItem<String>(value: 'logout', child: Text('تسجيل الخروج')),
              ],
            ),
          ],
        ),
        body: IndexedStack(index: selectedIndex, children: pages),
        bottomNavigationBar: NavigationBar(
          selectedIndex: selectedIndex,
          onDestinationSelected: (int value) => setState(() => selectedIndex = value),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'المرضى'),
            NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'المواعيد'),
            NavigationDestination(icon: Icon(Icons.healing_outlined), selectedIcon: Icon(Icons.healing), label: 'الجلسات'),
            NavigationDestination(icon: Icon(Icons.menu), label: 'المزيد'),
          ],
        ),
      );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(color: navy, borderRadius: BorderRadius.circular(20)),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('مرحبًا بك 👋', style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.bold)),
              SizedBox(height: 7),
              Text('إدارة المرضى والمواعيد والجلسات والحسابات من مكان واحد.', style: TextStyle(color: Colors.white70)),
            ],
          ),
        ),
        const SizedBox(height: 16),
        const SectionTitle('إحصائيات اليوم'),
        GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 2,
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1.45,
          children: const [
            StatCard(title: 'المرضى', value: '245', icon: Icons.people_outline),
            StatCard(title: 'مواعيد اليوم', value: '18', icon: Icons.calendar_today),
            StatCard(title: 'جلسات اليوم', value: '12', icon: Icons.healing),
            StatCard(title: 'المقبوضات', value: '85,000 ريال', icon: Icons.payments_outlined),
          ],
        ),
        const SizedBox(height: 18),
        const SectionTitle('الوصول السريع'),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: const [
            QuickAction(title: 'الفواتير', icon: Icons.receipt_long),
            QuickAction(title: 'الباقات', icon: Icons.inventory_2_outlined),
            QuickAction(title: 'إدارة الموظفين والأطباء', icon: Icons.badge_outlined),
            QuickAction(title: 'الحسابات والخزينة', icon: Icons.account_balance_wallet_outlined),
            QuickAction(title: 'المخزون', icon: Icons.warehouse_outlined),
            QuickAction(title: 'التقارير', icon: Icons.bar_chart_outlined),
          ],
        ),
      ],
    );
  }
}

class StatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const StatCard({super.key, required this.title, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Icon(icon, color: blue, size: 30),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(color: Colors.grey)),
                  const SizedBox(height: 4),
                  FittedBox(
                    fit: BoxFit.scaleDown,
                    alignment: Alignment.centerRight,
                    child: Text(value, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class QuickAction extends StatelessWidget {
  final String title;
  final IconData icon;

  const QuickAction({super.key, required this.title, required this.icon});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 150,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            children: [
              Icon(icon, color: blue, size: 28),
              const SizedBox(height: 8),
              Text(title, textAlign: TextAlign.center),
            ],
          ),
        ),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title;

  const SectionTitle(this.title, {super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: navy)),
    );
  }
}

class PatientsPage extends StatefulWidget {
  const PatientsPage({super.key});

  @override
  State<PatientsPage> createState() => _PatientsPageState();
}

class _PatientsPageState extends State<PatientsPage> {
  final TextEditingController searchController = TextEditingController();
  final List<Map<String, String>> patients = [
    {'no': 'PT-0001', 'name': 'أحمد محمد', 'phone': '770000000', 'service': 'علاج طبيعي'},
    {'no': 'PT-0002', 'name': 'محمد علي', 'phone': '733000000', 'service': 'تأهيل عصبي'},
  ];

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  Future<void> showPatientForm() async {
    final TextEditingController nameController = TextEditingController();
    final TextEditingController phoneController = TextEditingController();
    DateTime? dateOfBirth;

    await showDialog<void>(
      context: context,
      builder: (BuildContext dialogContext) {
        return StatefulBuilder(
          builder: (BuildContext ctx, StateSetter setDialogState) {
            return AlertDialog(
              title: const Text('إضافة مريض جديد'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(controller: nameController, decoration: const InputDecoration(labelText: 'الاسم الثلاثي')),
                    const SizedBox(height: 12),
                    TextField(
                      controller: phoneController,
                      keyboardType: TextInputType.phone,
                      decoration: const InputDecoration(labelText: 'رقم الهاتف'),
                    ),
                    const SizedBox(height: 12),
                    OutlinedButton.icon(
                      onPressed: () async {
                        final DateTime? picked = await showDatePicker(
                          context: ctx,
                          firstDate: DateTime(1900),
                          lastDate: DateTime.now(),
                          initialDate: dateOfBirth ?? DateTime(2000),
                          locale: const Locale('ar'),
                        );
                        if (picked != null) {
                          setDialogState(() => dateOfBirth = picked);
                        }
                      },
                      icon: const Icon(Icons.calendar_month),
                      label: Text(
                        dateOfBirth == null
                            ? 'تاريخ الميلاد: DD/MM/YYYY'
                            : 'تاريخ الميلاد: ${DateFormat('dd/MM/yyyy').format(dateOfBirth!)}',
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إلغاء')),
                FilledButton(
                  onPressed: () {
                    final String name = nameController.text.trim();
                    if (name.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('يرجى إدخال اسم المريض')));
                      return;
                    }
                    setState(() {
                      patients.insert(0, {
                        'no': 'PT-${(patients.length + 1).toString().padLeft(4, '0')}',
                        'name': name,
                        'phone': phoneController.text.trim(),
                        'service': 'غير محدد',
                      });
                    });
                    Navigator.pop(dialogContext);
                  },
                  child: const Text('حفظ'),
                ),
              ],
            );
          },
        );
      },
    );

    nameController.dispose();
    phoneController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final String query = searchController.text.trim();
    final Iterable<Map<String, String>> filtered = patients.where(
      (Map<String, String> patient) => query.isEmpty || patient.values.any((String value) => value.contains(query)),
    );

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            const Expanded(child: SectionTitle('المرضى والملفات')),
            FilledButton.icon(onPressed: showPatientForm, icon: const Icon(Icons.add), label: const Text('مريض جديد')),
          ],
        ),
        TextField(
          controller: searchController,
          onChanged: (_) => setState(() {}),
          decoration: const InputDecoration(
            prefixIcon: Icon(Icons.search),
            hintText: 'ابحث بالاسم أو الهاتف أو رقم الملف',
          ),
        ),
        const SizedBox(height: 12),
        ...filtered.map(
          (Map<String, String> patient) => Card(
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: blue,
                child: Text(patient['no']!.split('-').last, style: const TextStyle(color: Colors.white)),
              ),
              title: Text(patient['name']!),
              subtitle: Text('${patient['no']} • ${patient['phone']}\n${patient['service']}'),
              isThreeLine: true,
              trailing: const Icon(Icons.chevron_left),
            ),
          ),
        ),
      ],
    );
  }
}

class AppointmentsPage extends StatelessWidget {
  const AppointmentsPage({super.key});

  Future<void> pickAppointmentDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      initialDate: DateTime.now(),
      locale: const Locale('ar'),
    );
    if (picked != null && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تم اختيار التاريخ: ${DateFormat('dd/MM/yyyy').format(picked)}')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            const Expanded(child: SectionTitle('المواعيد')),
            FilledButton.icon(
              onPressed: () => pickAppointmentDate(context),
              icon: const Icon(Icons.add),
              label: const Text('موعد'),
            ),
          ],
        ),
        const Card(
          child: ListTile(
            leading: CircleAvatar(child: Icon(Icons.person)),
            title: Text('أحمد محمد – جلسة علاج طبيعي'),
            subtitle: Text('16/09/2026 • 10:00 • أخصائي العلاج الطبيعي'),
            trailing: Chip(label: Text('مؤكد')),
          ),
        ),
        const Card(
          child: ListTile(
            leading: CircleAvatar(child: Icon(Icons.person)),
            title: Text('محمد علي – متابعة'),
            subtitle: Text('16/09/2026 • 12:00 • عيادة المخ والأعصاب'),
            trailing: Chip(label: Text('محجوز')),
          ),
        ),
      ],
    );
  }
}

class SessionsPage extends StatelessWidget {
  const SessionsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            const Expanded(child: SectionTitle('الجلسات العلاجية')),
            FilledButton.icon(onPressed: () {}, icon: const Icon(Icons.add), label: const Text('تسجيل جلسة')),
          ],
        ),
        const Card(
          child: ListTile(
            title: Text('أحمد محمد'),
            subtitle: Text('علاج طبيعي • 16/09/2026'),
            trailing: Text('جلسة مكتملة'),
          ),
        ),
      ],
    );
  }
}

class EmployeesPage extends StatefulWidget {
  const EmployeesPage({super.key});

  @override
  State<EmployeesPage> createState() => _EmployeesPageState();
}

class _EmployeesPageState extends State<EmployeesPage> {
  final List<Map<String, dynamic>> employees = [
    {
      'name': 'د. أحمد محمد',
      'role': 'طبيب مخ وأعصاب',
      'phone': '770000001',
      'salary': 120000,
      'deductions': 5000,
      'present': 22,
      'absent': 1,
    },
    {
      'name': 'محمد علي',
      'role': 'أخصائي علاج طبيعي',
      'phone': '733000002',
      'salary': 90000,
      'deductions': 2500,
      'present': 24,
      'absent': 0,
    },
  ];

  String money(dynamic value) => '${NumberFormat('#,##0').format(value)} ريال';

  Future<void> showEmployeeForm({Map<String, dynamic>? employee}) async {
    final name = TextEditingController(text: employee?['name'] ?? '');
    final role = TextEditingController(text: employee?['role'] ?? '');
    final phone = TextEditingController(text: employee?['phone'] ?? '');
    final salary = TextEditingController(text: employee?['salary']?.toString() ?? '');
    final deductions = TextEditingController(text: employee?['deductions']?.toString() ?? '');

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(employee == null ? 'إضافة موظف / طبيب' : 'تعديل بيانات الموظف'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم الموظف / الطبيب')),
              const SizedBox(height: 10),
              TextField(controller: role, decoration: const InputDecoration(labelText: 'المسمى الوظيفي / التخصص')),
              const SizedBox(height: 10),
              TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'رقم الهاتف')),
              const SizedBox(height: 10),
              TextField(controller: salary, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'الراتب الأساسي')),
              const SizedBox(height: 10),
              TextField(controller: deductions, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'الاستقطاعات الشهرية')),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إلغاء')),
          FilledButton(
            onPressed: () {
              if (name.text.trim().isEmpty || role.text.trim().isEmpty) return;
              final item = <String, dynamic>{
                'name': name.text.trim(),
                'role': role.text.trim(),
                'phone': phone.text.trim(),
                'salary': double.tryParse(salary.text) ?? 0,
                'deductions': double.tryParse(deductions.text) ?? 0,
                'present': employee?['present'] ?? 0,
                'absent': employee?['absent'] ?? 0,
              };
              setState(() {
                if (employee == null) {
                  employees.add(item);
                } else {
                  final index = employees.indexOf(employee);
                  if (index >= 0) employees[index] = item;
                }
              });
              Navigator.pop(dialogContext);
            },
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
    name.dispose(); role.dispose(); phone.dispose(); salary.dispose(); deductions.dispose();
  }

  Future<void> showAttendance(Map<String, dynamic> employee) async {
    final today = DateFormat('dd/MM/yyyy').format(DateTime.now());
    String status = 'حاضر';
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: Text('حضور وغياب — ${employee['name']}'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(leading: const Icon(Icons.calendar_today), title: const Text('التاريخ'), subtitle: Text(today)),
              DropdownButtonFormField<String>(
                value: status,
                decoration: const InputDecoration(labelText: 'الحالة'),
                items: const [
                  DropdownMenuItem(value: 'حاضر', child: Text('حاضر')),
                  DropdownMenuItem(value: 'غائب', child: Text('غائب')),
                  DropdownMenuItem(value: 'إجازة', child: Text('إجازة')),
                  DropdownMenuItem(value: 'تأخير', child: Text('تأخير')),
                ],
                onChanged: (v) => setDialogState(() => status = v ?? 'حاضر'),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إلغاء')),
            FilledButton(
              onPressed: () {
                setState(() {
                  if (status == 'حاضر' || status == 'تأخير') employee['present'] = (employee['present'] as int) + 1;
                  if (status == 'غائب') employee['absent'] = (employee['absent'] as int) + 1;
                });
                Navigator.pop(dialogContext);
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تم تسجيل $status بتاريخ $today')));
              },
              child: const Text('تسجيل'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> showStatement(Map<String, dynamic> employee) async {
    final gross = employee['salary'] as num;
    final deductions = employee['deductions'] as num;
    final net = gross - deductions;
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text('كشف حساب الموظف — ${employee['name']}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('الراتب الأساسي: ${money(gross)}'),
            const SizedBox(height: 8),
            Text('الاستقطاعات: ${money(deductions)}'),
            const Divider(height: 24),
            Text('صافي المستحق: ${money(net)}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            const SizedBox(height: 12),
            Text('الحضور: ${employee['present']} يوم'),
            Text('الغياب: ${employee['absent']} يوم'),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إغلاق')),
          FilledButton.icon(
            onPressed: () {
              Navigator.pop(dialogContext);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تجهيز كشف الحساب للطباعة / PDF')));
            },
            icon: const Icon(Icons.picture_as_pdf),
            label: const Text('PDF'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            const Expanded(child: SectionTitle('إدارة الموظفين والأطباء')),
            FilledButton.icon(onPressed: () => showEmployeeForm(), icon: const Icon(Icons.add), label: const Text('إضافة')),
          ],
        ),
        const Text('الحضور والغياب • الرواتب • الاستقطاعات • كشوفات الحساب', style: TextStyle(color: Colors.grey)),
        const SizedBox(height: 12),
        ...employees.map((employee) {
          final net = (employee['salary'] as num) - (employee['deductions'] as num);
          return Card(
            child: ExpansionTile(
              leading: CircleAvatar(child: Icon(employee['role'].toString().contains('طبيب') ? Icons.medical_services : Icons.badge)),
              title: Text(employee['name']),
              subtitle: Text('${employee['role']} • ${employee['phone']}'),
              childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
              children: [
                Align(alignment: Alignment.centerRight, child: Text('صافي الراتب: ${money(net)}', style: const TextStyle(fontWeight: FontWeight.bold))),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    OutlinedButton.icon(onPressed: () => showAttendance(employee), icon: const Icon(Icons.fact_check_outlined), label: const Text('الحضور والغياب')),
                    OutlinedButton.icon(onPressed: () => showEmployeeForm(employee: employee), icon: const Icon(Icons.edit_outlined), label: const Text('تعديل')),
                    OutlinedButton.icon(onPressed: () => showStatement(employee), icon: const Icon(Icons.receipt_long_outlined), label: const Text('كشف الحساب')),
                  ],
                ),
              ],
            ),
          );
        }),
      ],
    );
  }
}

class NotificationsPage extends StatelessWidget {
  const NotificationsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const SectionTitle('الإشعارات والرسائل'),
        Card(
          child: ListTile(
            leading: const Icon(Icons.notifications_active_outlined, color: blue),
            title: const Text('تنبيهات النظام'),
            subtitle: const Text('المواعيد، الباقات، المخزون، الرواتب، وانتهاء التراخيص.'),
            trailing: Switch(value: true, onChanged: (_) {}),
          ),
        ),
        Card(
          child: ListTile(
            leading: const Icon(Icons.chat_outlined),
            title: const Text('WhatsApp / SMS'),
            subtitle: const Text('إعداد قوالب الرسائل وربط مزود API لإرسال الرسائل تلقائيًا.'),
            trailing: const Icon(Icons.chevron_left),
            onTap: () => showDialog<void>(
              context: context,
              builder: (ctx) => AlertDialog(
                title: const Text('إعداد الرسائل'),
                content: const Text('القوالب جاهزة للربط مع WhatsApp API وSMS. يلزم إدخال بيانات مزود الخدمة قبل الإرسال الفعلي.'),
                actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إغلاق'))],
              ),
            ),
          ),
        ),
        const Card(
          child: ListTile(
            leading: Icon(Icons.event_available_outlined),
            title: Text('تذكير المواعيد قبل 24 ساعة'),
            subtitle: Text('مفعّل — سيتم استخدام اسم المريض والتاريخ والوقت من قالب الرسالة.'),
            trailing: Icon(Icons.check_circle_outline),
          ),
        ),
      ],
    );
  }
}

class EmployeeStatementPage extends StatelessWidget {
  const EmployeeStatementPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const SectionTitle('كشوفات الحساب'),
        const Card(child: ListTile(leading: Icon(Icons.people_alt_outlined), title: Text('كشوفات حساب الموظفين والأطباء'), subtitle: Text('الرواتب • الاستقطاعات • المدفوعات • الرصيد المستحق'))),
        const Card(child: ListTile(leading: Icon(Icons.account_balance_wallet_outlined), title: Text('كشف حساب المركز'), subtitle: Text('الإيرادات • المصروفات • المقبوضات • الآجل'))),
        const SizedBox(height: 8),
        FilledButton.icon(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تجهيز تقرير PDF'))), icon: const Icon(Icons.picture_as_pdf), label: const Text('تصدير PDF')),
        const SizedBox(height: 8),
        OutlinedButton.icon(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تجهيز ملف Excel'))), icon: const Icon(Icons.table_view_outlined), label: const Text('تصدير Excel')),
      ],
    );
  }
}

class MorePage extends StatelessWidget {
  const MorePage({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> items = [
      {'title': 'إدارة الموظفين والأطباء', 'icon': Icons.badge_outlined, 'page': const EmployeesPage()},
      {'title': 'الفواتير والقبض', 'icon': Icons.receipt_long_outlined, 'page': const EmployeeStatementPage()},
      {'title': 'كشوفات الحساب', 'icon': Icons.account_balance_wallet_outlined, 'page': const EmployeeStatementPage()},
      {'title': 'الباقات العلاجية', 'icon': Icons.inventory_2_outlined},
      {'title': 'دليل الخدمات والأسعار', 'icon': Icons.medical_services_outlined},
      {'title': 'الحسابات والخزينة', 'icon': Icons.account_balance_outlined},
      {'title': 'المخزون والجرد', 'icon': Icons.warehouse_outlined},
      {'title': 'الإشعارات وWhatsApp / SMS', 'icon': Icons.notifications_active_outlined, 'page': const NotificationsPage()},
      {'title': 'التقارير والتصدير', 'icon': Icons.bar_chart_outlined},
      {'title': 'الإعدادات', 'icon': Icons.settings_outlined},
      {'title': 'النسخ الاحتياطي', 'icon': Icons.backup_outlined},
      {'title': 'الترخيص والاشتراك', 'icon': Icons.verified_user_outlined},
    ];

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const SectionTitle('المزيد'),
        ...items.map((item) => Card(
          child: ListTile(
            leading: Icon(item['icon'] as IconData, color: blue),
            title: Text(item['title'] as String),
            trailing: const Icon(Icons.chevron_left),
            onTap: () {
              final page = item['page'];
              if (page is Widget) {
                Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => page));
              } else {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('وحدة ${item['title']} جاهزة للتوسعة والربط')));
              }
            },
          ),
        )),
      ],
    );
  }
}

