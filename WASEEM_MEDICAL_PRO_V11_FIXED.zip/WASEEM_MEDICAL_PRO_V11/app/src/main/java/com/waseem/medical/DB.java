package com.waseem.medical;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class DB extends SQLiteOpenHelper {
    public DB(Context c){super(c,"waseem_medical.db",null,8);}
    public void onCreate(SQLiteDatabase d){
        d.execSQL("CREATE TABLE patients(id INTEGER PRIMARY KEY AUTOINCREMENT,file_no TEXT UNIQUE,name TEXT NOT NULL,phone TEXT,address TEXT,gender TEXT,dob TEXT,condition TEXT,service TEXT,department TEXT,therapist_id INTEGER,therapist TEXT,notes TEXT,created_at TEXT)");
        d.execSQL("CREATE TABLE staff(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,specialty TEXT,department TEXT,phone TEXT,pay_type TEXT,pay_value REAL DEFAULT 0,active INTEGER DEFAULT 1)");
        d.execSQL("CREATE TABLE services(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,department TEXT,price REAL DEFAULT 0,duration INTEGER DEFAULT 30,active INTEGER DEFAULT 1)");
        d.execSQL("CREATE TABLE patient_services(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER,service_id INTEGER,service_name TEXT,date TEXT,qty INTEGER DEFAULT 1,price REAL DEFAULT 0,discount REAL DEFAULT 0,notes TEXT)");
        d.execSQL("CREATE TABLE appointments(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER,patient_name TEXT,therapist_id INTEGER,therapist TEXT,date TEXT,time TEXT,status TEXT DEFAULT 'محجوز',service TEXT,notes TEXT)");
        d.execSQL("CREATE TABLE sessions(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER,patient_name TEXT,therapist_id INTEGER,therapist TEXT,date TEXT,service TEXT,status TEXT,notes TEXT,price REAL DEFAULT 0,package_id INTEGER)");
        d.execSQL("CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,number TEXT UNIQUE,patient_id INTEGER,patient_name TEXT,total REAL,discount REAL,paid REAL,method TEXT,status TEXT,date TEXT)");
        d.execSQL("CREATE TABLE invoice_items(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER,service TEXT,qty INTEGER,price REAL,discount REAL)");
        d.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER,patient_name TEXT,amount REAL,method TEXT,note TEXT,date TEXT)");
        d.execSQL("CREATE TABLE packages(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER,patient_name TEXT,name TEXT,total_sessions INTEGER,used_sessions INTEGER,price REAL,paid REAL,start_date TEXT,expiry_date TEXT,status TEXT)");
        d.execSQL("CREATE TABLE inventory(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,sku TEXT,quantity REAL,unit TEXT,cost REAL,min_qty REAL,active INTEGER DEFAULT 1)");
        d.execSQL("CREATE TABLE notifications(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,body TEXT,date TEXT,read INTEGER DEFAULT 0,type TEXT)");
        d.execSQL("CREATE TABLE messages(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER,patient_name TEXT,phone TEXT,type TEXT,body TEXT,status TEXT,date TEXT)");
        d.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY,v TEXT)");
        d.execSQL("CREATE TABLE audit(id INTEGER PRIMARY KEY AUTOINCREMENT,user_name TEXT,action TEXT,details TEXT,date TEXT)");
        seed(d);
    }
    public void onUpgrade(SQLiteDatabase d,int oldV,int newV){
        if(oldV<8){onCreateFreshUpgrade(d);}
    }
    private void onCreateFreshUpgrade(SQLiteDatabase d){
        // Keep existing data and add missing tables/columns where possible.
        String[] sql={
            "CREATE TABLE IF NOT EXISTS patient_services(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER,service_id INTEGER,service_name TEXT,date TEXT,qty INTEGER DEFAULT 1,price REAL DEFAULT 0,discount REAL DEFAULT 0,notes TEXT)",
            "CREATE TABLE IF NOT EXISTS invoice_items(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER,service TEXT,qty INTEGER,price REAL,discount REAL)",
            "CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY,v TEXT)",
            "CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,user_name TEXT,action TEXT,details TEXT,date TEXT)"};
        for(String s:sql)try{d.execSQL(s);}catch(Exception ignored){}
        seedMissing(d);
    }
    private void seed(SQLiteDatabase d){
        put(d,"center_name","المركز الأول للعلاج الطبيعي والتأهيل - دمت"); put(d,"slogan","خطوتك الأولى نحو صحة أفضل"); put(d,"phones","770237644 - 733844808 - 713651708"); put(d,"address","محافظة الضالع - مدينة دمت - شارع الدلة (المتفرع من فرزة يريم) - جوار صالة عامر ومحلات صالح خنداد - أمام محلات الموتى لمواد البناء"); put(d,"developer","وسيم الفرح لخدمات التقنية والأنظمة - 774486588"); put(d,"logo_uri","");
        String[][] s={{"العلاج الطبيعي","العلاج الطبيعي","0","60"},{"التأهيل العصبي","التأهيل","0","60"},{"الحجامة","الحجامة والمساج","0","45"},{"المساج العلاجي","الحجامة والمساج","0","45"},{"التغذية العلاجية","التغذية","0","30"},{"عيادة المخ والأعصاب","المخ والأعصاب","0","30"},{"الصالة الرياضية والتأهيل","التأهيل","0","45"}};
        for(String[] x:s)d.execSQL("INSERT OR IGNORE INTO services(name,department,price,duration,active) VALUES(?,?,?,?,1)",new Object[]{x[0],x[1],Double.parseDouble(x[2]),Integer.parseInt(x[3])});
        String[][] st={{"الأخصائي الرئيسي","علاج طبيعي","العلاج الطبيعي","","جلسة","0"},{"أخصائي التغذية","تغذية علاجية","التغذية","","جلسة","0"},{"طبيب المخ والأعصاب","مخ وأعصاب","المخ والأعصاب","","نسبة","0"}};
        for(String[] x:st)d.execSQL("INSERT INTO staff(name,specialty,department,phone,pay_type,pay_value,active) SELECT ?,?,?,?,?,?,1 WHERE NOT EXISTS(SELECT 1 FROM staff WHERE name=?)",new Object[]{x[0],x[1],x[2],x[3],x[4],Double.parseDouble(x[5]),x[0]});
        put(d,"welcome_msg","مرحبًا {name}، نرحب بك في {center}. نتمنى لك دوام الصحة والعافية.");
        put(d,"appointment_msg","مرحبًا {name}، نذكرك بموعدك في {center} بتاريخ {date} الساعة {time}. الخدمة: {service}.");
        put(d,"payment_msg","مرحبًا {name}، تم تسجيل دفعة بقيمة {amount} ريال. الرصيد المتبقي: {balance} ريال.");
        put(d,"appointment_reminder_enabled","1");
        notification("تم تجهيز النظام","مرحبًا بك في نظام وسيم الطبي — النسخة الاحترافية.","system");
    }
    private void seedMissing(SQLiteDatabase d){
        put(d,"center_name",setting(d,"center_name","المركز الأول للعلاج الطبيعي والتأهيل - دمت")); put(d,"slogan",setting(d,"slogan","خطوتك الأولى نحو صحة أفضل")); put(d,"phones",setting(d,"phones","770237644 - 733844808 - 713651708")); put(d,"address",setting(d,"address","محافظة الضالع - مدينة دمت")); put(d,"developer",setting(d,"developer","وسيم الفرح لخدمات التقنية والأنظمة - 774486588"));
    }
    private void put(SQLiteDatabase d,String k,String v){d.execSQL("INSERT OR IGNORE INTO settings(k,v) VALUES(?,?)",new Object[]{k,v});}

    private String setting(SQLiteDatabase d,String k,String def){Cursor c=d.rawQuery("SELECT v FROM settings WHERE k=?",new String[]{k});try{return c.moveToFirst()?c.getString(0):def;}finally{c.close();}}
    public String setting(String k,String def){Cursor c=getReadableDatabase().rawQuery("SELECT v FROM settings WHERE k=?",new String[]{k});try{return c.moveToFirst()?c.getString(0):def;}finally{c.close();}}
    public void set(String k,String v){getWritableDatabase().execSQL("INSERT OR REPLACE INTO settings(k,v) VALUES(?,?)",new Object[]{k,v});}
    public String now(){return new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date());}
    public String nextFile(){return "P"+String.format(Locale.US,"%06d",count("patients")+1);}
    public long addPatient(String name,String phone,String address,String gender,String dob,String condition,String service,String dept,long therapistId,String therapist,String notes){ContentValues v=new ContentValues();v.put("file_no",nextFile());v.put("name",name);v.put("phone",phone);v.put("address",address);v.put("gender",gender);v.put("dob",dob);v.put("condition",condition);v.put("service",service);v.put("department",dept);v.put("therapist_id",therapistId);v.put("therapist",therapist);v.put("notes",notes);v.put("created_at",now());long id=getWritableDatabase().insertOrThrow("patients",null,v);audit("تسجيل مريض",name); if(service!=null&&!service.isEmpty()) addPatientService(id,service,priceOf(service),1,0,"الخدمة الأولى"); notification("مريض جديد","تم تسجيل المريض: "+name,"patient");return id;}
    public long addPatientService(long pid,String service,double price,int qty,double discount,String notes){ContentValues v=new ContentValues();v.put("patient_id",pid);v.put("service_name",service);v.put("date",now());v.put("qty",qty);v.put("price",price);v.put("discount",discount);v.put("notes",notes);long id=getWritableDatabase().insert("patient_services",null,v);audit("إضافة خدمة للمريض",service);return id;}
    public long addStaff(String name,String specialty,String dept,String phone,String payType,double payValue){ContentValues v=new ContentValues();v.put("name",name);v.put("specialty",specialty);v.put("department",dept);v.put("phone",phone);v.put("pay_type",payType);v.put("pay_value",payValue);v.put("active",1);long id=getWritableDatabase().insert("staff",null,v);audit("إضافة طبيب/معالج",name);return id;}
    public void updateStaff(long id,String name,String specialty,String dept,String phone,String payType,double payValue){ContentValues v=new ContentValues();v.put("name",name);v.put("specialty",specialty);v.put("department",dept);v.put("phone",phone);v.put("pay_type",payType);v.put("pay_value",payValue);getWritableDatabase().update("staff",v,"id=?",new String[]{String.valueOf(id)});audit("تعديل طبيب/معالج",name);}
    public long addService(String name,String dept,double price,int duration){ContentValues v=new ContentValues();v.put("name",name);v.put("department",dept);v.put("price",price);v.put("duration",duration);v.put("active",1);long id=getWritableDatabase().insertOrThrow("services",null,v);audit("إضافة خدمة",name);return id;}
    public void updateService(long id,String name,String dept,double price,int duration){ContentValues v=new ContentValues();v.put("name",name);v.put("department",dept);v.put("price",price);v.put("duration",duration);getWritableDatabase().update("services",v,"id=?",new String[]{String.valueOf(id)});audit("تعديل خدمة",name);}
    public double priceOf(String service){Cursor c=query("SELECT price FROM services WHERE name=? AND active=1",new String[]{service});try{return c.moveToFirst()?c.getDouble(0):0;}finally{c.close();}}
    public long addAppointment(long pid,String pn,long tid,String therapist,String date,String time,String status,String service,String notes){ContentValues v=new ContentValues();v.put("patient_id",pid);v.put("patient_name",pn);v.put("therapist_id",tid);v.put("therapist",therapist);v.put("date",date);v.put("time",time);v.put("status",status);v.put("service",service);v.put("notes",notes);long id=getWritableDatabase().insert("appointments",null,v);audit("حجز موعد",pn+" - "+date+" "+time);notification("موعد جديد",pn+" — "+date+" "+time,"appointment");return id;}
    public long addSession(long pid,String pn,long tid,String therapist,String date,String service,String status,String notes,double price){ContentValues v=new ContentValues();v.put("patient_id",pid);v.put("patient_name",pn);v.put("therapist_id",tid);v.put("therapist",therapist);v.put("date",date);v.put("service",service);v.put("status",status);v.put("notes",notes);v.put("price",price);long id=getWritableDatabase().insert("sessions",null,v);audit("تسجيل جلسة",pn+" - "+service);return id;}
    public long addPayment(long pid,String pn,double amount,String method,String note){ContentValues v=new ContentValues();v.put("patient_id",pid);v.put("patient_name",pn);v.put("amount",amount);v.put("method",method);v.put("note",note);v.put("date",now());long id=getWritableDatabase().insert("payments",null,v);audit("تسجيل قبض",pn+" - "+amount);notification("قبض جديد","تم تسجيل قبض للمريض "+pn+" بقيمة "+amount+" ريال","payment");return id;}
    public long addInvoice(String num,long pid,String pn,double total,double disc,double paid,String method){ContentValues v=new ContentValues();v.put("number",num);v.put("patient_id",pid);v.put("patient_name",pn);v.put("total",total);v.put("discount",disc);v.put("paid",paid);v.put("method",method);v.put("status",paid>=total-disc?"مسدد":"متبقي");v.put("date",now());return getWritableDatabase().insert("invoices",null,v);}
    public long addMessage(long pid,String pn,String phone,String type,String body,String status){ContentValues v=new ContentValues();v.put("patient_id",pid);v.put("patient_name",pn);v.put("phone",phone);v.put("type",type);v.put("body",body);v.put("status",status);v.put("date",now());return getWritableDatabase().insert("messages",null,v);}
    public void notification(String title,String body,String type){ContentValues v=new ContentValues();v.put("title",title);v.put("body",body);v.put("date",now());v.put("read",0);v.put("type",type);getWritableDatabase().insert("notifications",null,v);}
    public int unread(){Cursor c=query("SELECT COUNT(*) FROM notifications WHERE read=0",null);try{c.moveToFirst();return c.getInt(0);}finally{c.close();}}
    public void markRead(){getWritableDatabase().execSQL("UPDATE notifications SET read=1");}
    public int count(String table){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+table,null);try{c.moveToFirst();return c.getInt(0);}finally{c.close();}}
    public double sum(String table,String col){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM("+col+"),0) FROM "+table,null);try{c.moveToFirst();return c.getDouble(0);}finally{c.close();}}
    public Cursor query(String sql,String[] args){return getReadableDatabase().rawQuery(sql,args);}
    public double patientCharges(long pid){Cursor c=query("SELECT COALESCE(SUM((price*qty)-discount),0) FROM patient_services WHERE patient_id=?",new String[]{String.valueOf(pid)});try{c.moveToFirst();return c.getDouble(0);}finally{c.close();}}
    public double patientPaid(long pid){Cursor c=query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE patient_id=?",new String[]{String.valueOf(pid)});try{c.moveToFirst();return c.getDouble(0);}finally{c.close();}}
    public void audit(String action,String details){ContentValues v=new ContentValues();v.put("user_name","مدير المركز");v.put("action",action);v.put("details",details);v.put("date",now());getWritableDatabase().insert("audit",null,v);}
}
