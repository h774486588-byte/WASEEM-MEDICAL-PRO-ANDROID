# Waseem Medical Pro rules
