# Backend integration layer

هذه المجلدات مهيأة لربط النسخة المحلية بخادم سحابي آمن. لا تضع مفاتيح WhatsApp/SMS/Google داخل APK.

المقترح الإنتاجي: REST API + PostgreSQL + JWT/refresh tokens + RBAC + audit log + encrypted backups.
