# Production integrations

## WhatsApp
استخدم WhatsApp Business Platform/Cloud API من خادم Backend. خزّن access token في GitHub Secrets أو Secret Manager.

## SMS
اربط مزود SMS يدعم اليمن عبر Backend، مع سجل delivery status ومنع التكرار.

## Google Drive
OAuth 2.0 من الخادم مع refresh token مشفر، وليس داخل APK.

## Licensing
النسخة التجارية تحتاج خادم تراخيص يربط installation/device identifier بالاشتراك وتاريخ الانتهاء مع فترة سماح offline.

## Payments
لا تخزن بيانات البطاقات. استخدم مزود دفع متوافقًا مع السوق المستهدف، وتحقق من webhooks على الخادم.
