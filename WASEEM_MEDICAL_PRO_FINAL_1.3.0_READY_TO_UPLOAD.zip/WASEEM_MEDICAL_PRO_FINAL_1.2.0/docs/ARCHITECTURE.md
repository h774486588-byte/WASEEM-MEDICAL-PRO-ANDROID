# Architecture

Android client (offline-first) -> optional secure Backend API -> PostgreSQL.

المبادئ: فصل الواجهة عن البيانات، RBAC، Audit Log، عدم تضمين الأسرار في التطبيق، نسخ احتياطي قبل العمليات الحساسة، وقابلية تعدد الفروع.
