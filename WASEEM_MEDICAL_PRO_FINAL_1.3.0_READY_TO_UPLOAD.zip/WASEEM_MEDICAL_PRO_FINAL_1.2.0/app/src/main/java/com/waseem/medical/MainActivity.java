package com.waseem.medical;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.content.ContentValues;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private DB db;
    private LinearLayout root, content;
    private final int NAVY = Color.rgb(18,48,74);
    private final int BLUE = Color.rgb(30,111,168);
    private final int GREEN = Color.rgb(46,139,87);
    private final int BG = Color.rgb(245,248,251);
    private final int TEXT = Color.rgb(24,49,66);
    private final int MUTED = Color.rgb(107,125,137);
    private final int WHITE = Color.WHITE;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        db = new DB(this);
        showDashboard();
    }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        t.setPadding(dp(4), dp(4), dp(4), dp(4));
        return t;
    }

    private GradientDrawable bg(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        return g;
    }

    private TextView actionButton(String label, String icon, int color) {
        TextView b = text(label + "  " + icon, 15, WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(bg(color, 14));
        b.setPadding(dp(14), dp(4), dp(14), dp(4));
        b.setIncludeFontPadding(true);
        b.setMinHeight(dp(58));
        b.setElevation(dp(2));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(58));
        p.setMargins(dp(5), dp(5), dp(5), dp(5));
        b.setLayoutParams(p);
        return b;
    }

    private EditText input(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextSize(15);
        e.setTextColor(TEXT);
        e.setHintTextColor(MUTED);
        e.setSingleLine(false);
        e.setPadding(dp(14), dp(6), dp(14), dp(6));
        e.setBackground(bg(WHITE, 12));
        e.setElevation(dp(1));
        e.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(56)));
        return e;
    }

    private void base(String page) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        setContentView(root);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), 0, dp(8), 0);
        bar.setBackgroundColor(NAVY);

        TextView menu = text("☰", 25, WHITE, false);
        menu.setGravity(Gravity.CENTER);
        menu.setOnClickListener(v -> showMenu());
        bar.addView(menu, new LinearLayout.LayoutParams(dp(54), dp(64)));

        TextView title = text(page, 18, WHITE, true);
        title.setGravity(Gravity.CENTER);
        bar.addView(title, new LinearLayout.LayoutParams(0, dp(64), 1));

        TextView bell = text("🔔", 19, WHITE, false);
        bell.setGravity(Gravity.CENTER);
        bell.setOnClickListener(v -> appointmentsPage());
        bar.addView(bell, new LinearLayout.LayoutParams(dp(54), dp(64)));
        root.addView(bar);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(14), dp(14), dp(30));
        content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    private TextView section(String s) {
        TextView t = text(s, 18, NAVY, true);
        t.setPadding(0, dp(14), 0, dp(7));
        content.addView(t);
        return t;
    }

    private void card(View v) {
        if (v instanceof TextView) {
            ((TextView)v).setBackground(bg(WHITE, 14));
            ((TextView)v).setPadding(dp(14), dp(12), dp(14), dp(12));
        }
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(5), 0, dp(5));
        content.addView(v, p);
    }

    private void showDashboard() {
        base("المركز الأول للعلاج الطبيعي والتأهيل | دمت");
        String now = new SimpleDateFormat("EEEE، dd-MM-yyyy | HH:mm", new Locale("ar")).format(new Date());
        TextView welcome = text("ماذا تريد أن تنجز؟", 24, NAVY, true);
        welcome.setPadding(0, dp(8), 0, dp(2));
        content.addView(welcome);
        content.addView(text(now, 14, MUTED, false));
        content.addView(text("خطوتك الأولى نحو صحة أفضل", 14, GREEN, true));

        section("الوصول السريع");
        String[][] actions = {
                {"تسجيل مريض جديد","👤","patient"}, {"حجز موعد","📅","appointment"},
                {"ملف مريض","📁","patients"}, {"إصدار فاتورة","🧾","invoice"},
                {"تسجيل جلسة","🩺","session"}, {"تسجيل قبض","💵","payment"},
                {"كشف حساب","📒","statement"}, {"تقارير الحالات","📊","cases"}
        };
        for (String[] a : actions) {
            TextView b = actionButton(a[0], a[1], BLUE);
            content.addView(b);
            b.setOnClickListener(v -> route(a[2]));
        }

        section("ملخص اليوم");
        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        addStat(stats, "المرضى", count("patients"), BLUE);
        addStat(stats, "المواعيد", count("appointments"), GREEN);
        addStat(stats, "الجلسات", count("sessions"), NAVY);
        content.addView(stats, new LinearLayout.LayoutParams(-1, dp(92)));

        TextView reminders = actionButton("تذكيرات المواعيد", "🔔", GREEN);
        content.addView(reminders);
        reminders.setOnClickListener(v -> appointmentsPage());
    }

    private void addStat(LinearLayout parent, String label, int value, int color) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackground(bg(WHITE, 14));
        TextView n = text(String.valueOf(value), 22, color, true); n.setGravity(Gravity.CENTER);
        TextView l = text(label, 12, MUTED, false); l.setGravity(Gravity.CENTER);
        box.addView(n, new LinearLayout.LayoutParams(-1, 0, 1));
        box.addView(l, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, 1);
        p.setMargins(dp(3), 0, dp(3), 0);
        parent.addView(box, p);
    }

    private int count(String table) {
        Cursor c = db.query("SELECT COUNT(*) FROM " + table, null);
        c.moveToFirst(); int n = c.getInt(0); c.close(); return n;
    }

    private void route(String x) {
        switch (x) {
            case "patient": patientForm(); break; case "patients": patientsPage(); break;
            case "appointment": appointmentForm(); break; case "invoice": invoiceForm(); break;
            case "session": sessionForm(); break; case "payment": paymentForm(); break;
            case "statement": statementPage(); break; case "cases": casesPage(); break;
        }
    }

    private void patientForm() {
        base("تسجيل مريض جديد");
        content.addView(text("البيانات الأساسية", 18, NAVY, true));
        EditText name=input("اسم المريض *"), phone=input("رقم الهاتف / واتساب"), address=input("العنوان"), gender=input("الجنس: ذكر / أنثى"), birth=input("تاريخ الميلاد"), caseN=input("الحالة / المرض"), service=input("الخدمة المطلوبة"), dep=input("القسم"), notes=input("ملاحظات");
        EditText[] fields={name,phone,address,gender,birth,caseN,service,dep,notes};
        for(EditText e:fields){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(56));p.setMargins(0,dp(4),0,dp(4));content.addView(e,p); }
        TextView save=actionButton("حفظ المريض", "💾", GREEN); content.addView(save);
        save.setOnClickListener(v->{
            if(name.getText().toString().trim().isEmpty()){toast("أدخل اسم المريض");return;}
            ContentValues x=new ContentValues();
            x.put("file_no","P-"+new SimpleDateFormat("yyyyMMddHHmmss",Locale.US).format(new Date()));
            x.put("name",name.getText().toString().trim()); x.put("phone",phone.getText().toString().trim()); x.put("address",address.getText().toString().trim());
            x.put("gender",gender.getText().toString().trim()); x.put("birth",birth.getText().toString().trim()); x.put("case_name",caseN.getText().toString().trim());
            x.put("service",service.getText().toString().trim()); x.put("department",dep.getText().toString().trim()); x.put("notes",notes.getText().toString().trim()); x.put("created_at",DB.now());
            long id=db.addPatient(x); db.log("تسجيل مريض","ID="+id); toast("تم حفظ المريض\nرقم الملف: "+x.getAsString("file_no"));
        });
    }

    private void patientsPage() {
        base("ملفات المرضى");
        EditText q=input("ابحث بالاسم أو الهاتف أو رقم الملف"); content.addView(q);
        TextView search=actionButton("بحث", "🔎", BLUE); content.addView(search);
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); content.addView(list,new LinearLayout.LayoutParams(-1,-2));
        Runnable load=()->{list.removeAllViews(); Cursor c=db.patients(q.getText().toString().trim()); while(c.moveToNext()){
            final long id=c.getLong(c.getColumnIndexOrThrow("id")); String s=c.getString(c.getColumnIndexOrThrow("file_no"))+"  |  "+c.getString(c.getColumnIndexOrThrow("name"))+"\n"+safe(c,"phone")+"  |  "+safe(c,"case_name");
            TextView row=text(s,14,TEXT,false); row.setBackground(bg(WHITE,12)); row.setPadding(dp(14),dp(12),dp(14),dp(12)); list.addView(row,new LinearLayout.LayoutParams(-1,dp(74))); row.setOnClickListener(v->patientDetails(id)); } c.close();};
        search.setOnClickListener(v->load.run()); load.run();
    }

    private String safe(Cursor c,String col){int i=c.getColumnIndex(col);return i>=0 && !c.isNull(i)?c.getString(i):"";}

    private void patientDetails(long id){
        Cursor c=db.query("SELECT * FROM patients WHERE id=?",new String[]{String.valueOf(id)}); if(!c.moveToFirst()){c.close();return;}
        String s="رقم الملف: "+safe(c,"file_no")+"\nالاسم: "+safe(c,"name")+"\nالهاتف: "+safe(c,"phone")+"\nالحالة: "+safe(c,"case_name")+"\nالخدمة: "+safe(c,"service")+"\nالقسم: "+safe(c,"department")+"\nتاريخ التسجيل: "+safe(c,"created_at"); c.close();
        new AlertDialog.Builder(this).setTitle("ملف المريض").setMessage(s).setPositiveButton("إغلاق",null).setNeutralButton("كشف الحساب",(d,w)->statementFor(id)).show();
    }

    private long patientIdFromInput(EditText e){
        String q=e.getText().toString().trim();
        if(q.isEmpty()) return 0;
        try { return Long.parseLong(q); } catch(Exception ignored) {}
        Cursor c=db.query("SELECT id FROM patients WHERE file_no=? LIMIT 1",new String[]{q});
        long id=0; if(c.moveToFirst()) id=c.getLong(0); c.close(); return id;
    }

    private void appointmentForm(){
        base("حجز موعد");
        EditText pid=input("رقم ملف المريض"),date=input("التاريخ YYYY-MM-DD"),time=input("الوقت"),doctor=input("الأخصائي"),service=input("الخدمة"),notes=input("ملاحظات"); date.setText(DB.today());
        for(EditText e:new EditText[]{pid,date,time,doctor,service,notes})content.addView(e,new LinearLayout.LayoutParams(-1,dp(56)));
        TextView save=actionButton("حفظ الموعد","📅",GREEN);content.addView(save);save.setOnClickListener(v->{
            long patientId=patientIdFromInput(pid); if(patientId<=0){toast("أدخل رقم الملف الصحيح أو رقم المريض");return;}
            ContentValues x=new ContentValues();x.put("patient_id",patientId);x.put("date",date.getText().toString());x.put("time",time.getText().toString());x.put("doctor",doctor.getText().toString());x.put("service",service.getText().toString());x.put("status","مؤكد");x.put("notes",notes.getText().toString());
            db.insert("appointments",x);db.log("حجز موعد",date.getText()+" "+time.getText());toast("تم حفظ الموعد");
        });
    }

    private void appointmentsPage(){
        base("مواعيد اليوم");
        Cursor c=db.query("SELECT a.date,a.time,a.doctor,a.service,a.status,p.name,p.file_no FROM appointments a LEFT JOIN patients p ON p.id=a.patient_id ORDER BY a.date DESC,a.time DESC",null);
        while(c.moveToNext()){
            TextView row=text(c.getString(5)+"  |  "+c.getString(6)+"\n"+c.getString(0)+"  "+c.getString(1)+"  |  "+c.getString(3)+"\nالأخصائي: "+c.getString(2)+"  |  "+c.getString(4),14,TEXT,false);row.setBackground(bg(WHITE,12));row.setPadding(dp(14),dp(10),dp(14),dp(10));content.addView(row,new LinearLayout.LayoutParams(-1,dp(92)));
        } c.close();
    }

    private void sessionForm(){base("تسجيل جلسة");EditText pid=input("رقم ملف المريض"),service=input("الخدمة"),doctor=input("الأخصائي"),notes=input("ملاحظات الجلسة");for(EditText e:new EditText[]{pid,service,doctor,notes})content.addView(e,new LinearLayout.LayoutParams(-1,dp(56)));TextView b=actionButton("تسجيل الجلسة","🩺",GREEN);content.addView(b);b.setOnClickListener(v->{long patientId=patientIdFromInput(pid);if(patientId<=0){toast("أدخل رقم الملف الصحيح أو رقم المريض");return;}ContentValues x=new ContentValues();x.put("patient_id",patientId);x.put("date",DB.now());x.put("service",service.getText().toString());x.put("doctor",doctor.getText().toString());x.put("notes",notes.getText().toString());db.insert("sessions",x);db.log("تسجيل جلسة","patient="+pid.getText());toast("تم تسجيل الجلسة");});}

    private void invoiceForm(){base("إصدار فاتورة");EditText pid=input("رقم ملف المريض"),total=input("إجمالي الفاتورة"),paid=input("المدفوع"),method=input("طريقة الدفع: نقدي / تحويل / شبكة"),notes=input("البيان");for(EditText e:new EditText[]{pid,total,paid,method,notes})content.addView(e,new LinearLayout.LayoutParams(-1,dp(56)));TextView b=actionButton("حفظ الفاتورة","🧾",GREEN);content.addView(b);b.setOnClickListener(v->{long patientId=patientIdFromInput(pid);double t=num(total),p=num(paid);if(patientId<=0){toast("أدخل رقم الملف الصحيح أو رقم المريض");return;}if(t<=0||p<0||p>t){toast("تحقق من إجمالي الفاتورة والمدفوع");return;}ContentValues x=new ContentValues();x.put("patient_id",patientId);x.put("date",DB.now());x.put("total",t);x.put("paid",p);x.put("method",method.getText().toString());x.put("notes",notes.getText().toString());long id=db.insert("invoices",x);if(p>0){ContentValues cash=new ContentValues();cash.put("date",DB.now());cash.put("type","قبض");cash.put("amount",p);cash.put("method",method.getText().toString());cash.put("description","قبض فاتورة #"+id);cash.put("user_name","المستخدم");db.insert("cash",cash);ContentValues pay=new ContentValues();pay.put("patient_id",patientId);pay.put("date",DB.now());pay.put("amount",p);pay.put("method",method.getText().toString());pay.put("notes","قبض مرتبط بالفاتورة #"+id);db.insert("payments",pay);}db.log("إصدار فاتورة","#"+id);toast("تم حفظ الفاتورة\nالمتبقي: "+money(t-p)+" ر.ي");});}

    private void paymentForm(){base("تسجيل قبض");EditText pid=input("رقم ملف المريض"),amount=input("المبلغ"),method=input("طريقة الدفع"),notes=input("البيان");for(EditText e:new EditText[]{pid,amount,method,notes})content.addView(e,new LinearLayout.LayoutParams(-1,dp(56)));TextView b=actionButton("حفظ القبض","💵",GREEN);content.addView(b);b.setOnClickListener(v->{long patientId=patientIdFromInput(pid);double a=num(amount);if(patientId<=0){toast("أدخل رقم الملف الصحيح أو رقم المريض");return;}if(a<=0){toast("أدخل مبلغًا صحيحًا");return;}ContentValues x=new ContentValues();x.put("patient_id",patientId);x.put("date",DB.now());x.put("amount",a);x.put("method",method.getText().toString());x.put("notes",notes.getText().toString());db.insert("payments",x);ContentValues cash=new ContentValues();cash.put("date",DB.now());cash.put("type","قبض");cash.put("amount",a);cash.put("method",method.getText().toString());cash.put("description","قبض من المريض #"+patientId);cash.put("user_name","المستخدم");db.insert("cash",cash);db.log("تسجيل قبض",money(a));toast("تم تسجيل القبض");});}

    private void statementPage(){base("كشف الحساب");EditText pid=input("رقم ملف المريض");content.addView(pid);TextView b=actionButton("عرض كشف الحساب","📒",BLUE);content.addView(b);TextView out=text("",15,TEXT,false);card(out);b.setOnClickListener(v->{long patientId=patientIdFromInput(pid);if(patientId<=0){out.setText("لم يتم العثور على المريض");return;}statementText(patientId,out);});}
    private void statementFor(long id){base("كشف حساب المريض");TextView out=text("",15,TEXT,false);card(out);statementText(id,out);}
    private void statementText(long id,TextView out){Cursor p=db.query("SELECT name,file_no FROM patients WHERE id=?",new String[]{String.valueOf(id)});if(!p.moveToFirst()){p.close();out.setText("لم يتم العثور على المريض");return;}String name=p.getString(0),file=p.getString(1);p.close();Cursor a=db.query("SELECT COALESCE(SUM(total),0) FROM invoices WHERE patient_id=?",new String[]{String.valueOf(id)});a.moveToFirst();double total=a.getDouble(0);a.close();Cursor q=db.query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE patient_id=?",new String[]{String.valueOf(id)});q.moveToFirst();double paid=q.getDouble(0);q.close();double bal=total-paid;String status=bal>0?"متبقي على المريض":bal<0?"رصيد للمريض":"الحساب مسدد بالكامل";out.setText("المريض: "+name+"\nرقم الملف: "+file+"\n\nإجمالي الخدمات: "+money(total)+" ر.ي\nإجمالي المدفوع: "+money(paid)+" ر.ي\nالرصيد: "+money(Math.abs(bal))+" ر.ي\n\n"+status);}

    private void casesPage(){base("تقارير الحالات");Cursor c=db.query("SELECT case_name,COUNT(*) n FROM patients WHERE case_name IS NOT NULL AND case_name<>'' GROUP BY case_name ORDER BY n DESC",null);if(!c.moveToFirst()){content.addView(text("لا توجد حالات مسجلة حتى الآن.",15,MUTED,false));}else{do{String cs=c.getString(0),n=c.getString(1);TextView b=actionButton(cs+" — "+n+" مريض","📊",BLUE);content.addView(b);b.setOnClickListener(v->casePatients(cs));}while(c.moveToNext());}c.close();}
    private void casePatients(String cs){base("الحالة: "+cs);Cursor c=db.query("SELECT file_no,name,phone,service,created_at FROM patients WHERE case_name=? ORDER BY id DESC",new String[]{cs});while(c.moveToNext()){TextView r=text(c.getString(0)+"  |  "+c.getString(1)+"\n"+safe(c,"phone")+"  |  "+safe(c,"service")+"\n"+safe(c,"created_at"),14,TEXT,false);card(r);}c.close();}

    private void showMenu(){final String[] items={"الإعدادات","دليل الخدمات والحالات","الأطباء والأخصائيون والموظفون","الخزينة","المخزون والجرد","التقارير","النسخ الاحتياطي","الأمان وسجل العمليات","بيانات المركز","عن النظام"};new AlertDialog.Builder(this).setTitle("القائمة الرئيسية").setItems(items,(d,w)->{switch(w){case 0:settings();break;case 1:servicesPage();break;case 2:staffPage();break;case 3:cashPage();break;case 4:inventoryPage();break;case 5:reportsPage();break;case 6:backup();break;case 7:auditPage();break;case 8:settings();break;default:toast("نظام وسيم الطبي — إصدار 1.3.0");}}).show();}

    private void settings(){base("إعدادات المركز");EditText name=input("اسم المركز");name.setText(db.setting("center_name"));EditText branch=input("اسم الفرع");branch.setText(db.setting("branch"));EditText phone=input("الهاتف / واتساب");phone.setText(db.setting("phone"));EditText address=input("العنوان");address.setText(db.setting("address"));for(EditText e:new EditText[]{name,branch,phone,address})content.addView(e,new LinearLayout.LayoutParams(-1,dp(60)));TextView b=actionButton("حفظ الإعدادات","⚙️",GREEN);content.addView(b);b.setOnClickListener(v->{set("center_name",name.getText().toString());set("branch",branch.getText().toString());set("phone",phone.getText().toString());set("address",address.getText().toString());toast("تم حفظ الإعدادات");});content.addView(text("يمكن إضافة WhatsApp API وSMS وGoogle Drive لاحقًا باستخدام مفاتيح الخدمات الفعلية دون وضع الأسرار داخل التطبيق.",13,MUTED,false));}
    private void set(String k,String v){ContentValues x=new ContentValues();x.put("v",v);db.update("settings",x,"k=?",new String[]{k});}

    private void servicesPage(){base("دليل الخدمات والحالات");Cursor c=db.all("services");while(c.moveToNext()){TextView r=text(c.getString(c.getColumnIndexOrThrow("name"))+"\n"+c.getString(c.getColumnIndexOrThrow("department"))+" | "+money(c.getDouble(c.getColumnIndexOrThrow("price")))+" ر.ي",14,TEXT,false);card(r);}c.close();}
    private void staffPage(){base("الأطباء والأخصائيون والموظفون");TextView add=actionButton("إضافة أخصائي / موظف","👨‍⚕️",GREEN);content.addView(add);add.setOnClickListener(v->staffForm());Cursor c=db.all("staff");while(c.moveToNext()){card(text(c.getString(c.getColumnIndexOrThrow("name"))+" | "+c.getString(c.getColumnIndexOrThrow("role"))+" | "+c.getString(c.getColumnIndexOrThrow("specialty")),14,TEXT,false));}c.close();}
    private void staffForm(){base("إضافة موظف");EditText name=input("الاسم"),role=input("المسمى الوظيفي"),spec=input("التخصص"),dep=input("القسم"),phone=input("الهاتف"),salary=input("الراتب"),percent=input("نسبة الأخصائي %");for(EditText e:new EditText[]{name,role,spec,dep,phone,salary,percent})content.addView(e,new LinearLayout.LayoutParams(-1,dp(56)));TextView b=actionButton("حفظ","💾",GREEN);content.addView(b);b.setOnClickListener(v->{ContentValues x=new ContentValues();x.put("name",name.getText().toString());x.put("role",role.getText().toString());x.put("specialty",spec.getText().toString());x.put("department",dep.getText().toString());x.put("phone",phone.getText().toString());x.put("salary",num(salary));x.put("percent",num(percent));db.insert("staff",x);db.log("إضافة موظف",name.getText().toString());toast("تم الحفظ");});}
    private void cashPage(){base("الخزينة");Cursor c=db.query("SELECT COALESCE(SUM(CASE WHEN type='قبض' THEN amount ELSE 0 END),0)-COALESCE(SUM(CASE WHEN type='مصروف' THEN amount ELSE 0 END),0) FROM cash",null);c.moveToFirst();double cash=c.getDouble(0);c.close();card(text("الرصيد الحالي للخزينة\n"+money(cash)+" ر.ي",21,NAVY,true));EditText type=input("النوع: قبض أو مصروف"),amount=input("المبلغ"),desc=input("البيان");for(EditText e:new EditText[]{type,amount,desc})content.addView(e,new LinearLayout.LayoutParams(-1,dp(56)));TextView b=actionButton("تسجيل حركة","💰",GREEN);content.addView(b);b.setOnClickListener(v->{double a=num(amount);if(a<=0){toast("أدخل مبلغًا صحيحًا");return;}ContentValues x=new ContentValues();x.put("date",DB.now());x.put("type",type.getText().toString());x.put("amount",a);x.put("method","نقدي");x.put("description",desc.getText().toString());x.put("user_name","المستخدم");db.insert("cash",x);db.log("حركة خزينة",type.getText().toString()+" "+money(a));toast("تم تسجيل الحركة");cashPage();});}
    private void inventoryPage(){base("المخزون والجرد");TextView add=actionButton("إضافة صنف","📦",GREEN);content.addView(add);add.setOnClickListener(v->inventoryForm());Cursor c=db.all("inventory");while(c.moveToNext()){card(text(c.getString(c.getColumnIndexOrThrow("name"))+"\nباركود: "+safe(c,"barcode")+" | الكمية: "+money(c.getDouble(c.getColumnIndexOrThrow("qty"))),14,TEXT,false));}c.close();}
    private void inventoryForm(){base("إضافة صنف");EditText n=input("اسم الصنف"),barcode=input("الباركود"),unit=input("الوحدة"),qty=input("الكمية"),cost=input("تكلفة الشراء"),sale=input("سعر البيع"),min=input("الحد الأدنى"),exp=input("الصلاحية");for(EditText e:new EditText[]{n,barcode,unit,qty,cost,sale,min,exp})content.addView(e,new LinearLayout.LayoutParams(-1,dp(56)));TextView b=actionButton("حفظ الصنف","📦",GREEN);content.addView(b);b.setOnClickListener(v->{if(n.getText().toString().trim().isEmpty()){toast("أدخل اسم الصنف");return;}ContentValues x=new ContentValues();x.put("name",n.getText().toString());x.put("barcode",barcode.getText().toString());x.put("unit",unit.getText().toString());x.put("qty",num(qty));x.put("cost",num(cost));x.put("sale",num(sale));x.put("min_qty",num(min));x.put("expiry",exp.getText().toString());db.insert("inventory",x);db.log("إضافة صنف",n.getText().toString());toast("تم حفظ الصنف");});}
    private void reportsPage(){base("التقارير");content.addView(text("التقارير الأساسية",19,NAVY,true));String[] rs={"تقرير المرضى","تقرير المواعيد","تقرير الجلسات","التقرير المالي","تقرير المخزون","أداء الأخصائيين","تقارير الحالات"};for(String r:rs){TextView b=actionButton(r,"📄",BLUE);content.addView(b);b.setOnClickListener(v->toast("تم اختيار: "+r+" — التصدير PDF/Excel يضاف في المرحلة التالية."));}}
    private void auditPage(){base("سجل العمليات");Cursor c=db.all("audit");while(c.moveToNext()){card(text(safe(c,"date")+"\n"+safe(c,"action")+"\n"+safe(c,"details"),13,TEXT,false));}c.close();}
    private void backup(){try{String path=getExternalFilesDir(null)+"/waseem_medical_backup_"+System.currentTimeMillis()+".txt";java.io.FileWriter w=new java.io.FileWriter(path);String[] tables={"patients","appointments","sessions","invoices","payments","packages","inventory","staff","cash","audit","settings"};for(String t:tables){w.write("### "+t+" ###\n");Cursor c=db.all(t);while(c.moveToNext()){for(int i=0;i<c.getColumnCount();i++){if(i>0)w.write(" | ");w.write(c.getColumnName(i)+"="+(c.isNull(i)?"":c.getString(i)));}w.write("\n");}c.close();}w.close();toast("تم إنشاء النسخة الاحتياطية محليًا");}catch(Exception e){toast("تعذر إنشاء النسخة: "+e.getMessage());}}
    private long parse(EditText e){try{return Long.parseLong(e.getText().toString().trim());}catch(Exception x){return 0;}}
    private double num(EditText e){try{return Double.parseDouble(e.getText().toString().trim().replace(",","."));}catch(Exception x){return 0;}}
    private String money(double n){return new java.text.DecimalFormat("#,##0.##",new java.text.DecimalFormatSymbols(Locale.US)).format(n);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
