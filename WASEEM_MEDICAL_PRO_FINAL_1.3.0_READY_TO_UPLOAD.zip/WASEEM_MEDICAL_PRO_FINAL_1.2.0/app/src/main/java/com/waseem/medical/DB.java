package com.waseem.medical;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

public class DB extends SQLiteOpenHelper {
    public DB(Context c){super(c,"waseem_medical.db",null,4);}
    public void onCreate(SQLiteDatabase d){
        d.execSQL("CREATE TABLE patients(id INTEGER PRIMARY KEY AUTOINCREMENT,file_no TEXT UNIQUE,name TEXT NOT NULL,phone TEXT,whatsapp TEXT,address TEXT,gender TEXT,birth TEXT,case_name TEXT,service TEXT,department TEXT,notes TEXT,created_at TEXT)");
        d.execSQL("CREATE TABLE services(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,department TEXT,price REAL,active INTEGER DEFAULT 1)");
        d.execSQL("CREATE TABLE appointments(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER,date TEXT,time TEXT,doctor TEXT,service TEXT,status TEXT,notes TEXT)");
        d.execSQL("CREATE TABLE sessions(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER,date TEXT,service TEXT,doctor TEXT,notes TEXT,package_id INTEGER DEFAULT 0)");
        d.execSQL("CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER,date TEXT,total REAL,paid REAL,method TEXT,notes TEXT)");
        d.execSQL("CREATE TABLE invoice_items(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER,service TEXT,qty INTEGER,price REAL)");
        d.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER,date TEXT,amount REAL,method TEXT,notes TEXT)");
        d.execSQL("CREATE TABLE packages(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER,name TEXT,total_sessions INTEGER,used_sessions INTEGER DEFAULT 0,price REAL,paid REAL,start_date TEXT,end_date TEXT,status TEXT)");
        d.execSQL("CREATE TABLE inventory(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,barcode TEXT,unit TEXT,qty REAL,cost REAL,sale REAL,min_qty REAL,expiry TEXT)");
        d.execSQL("CREATE TABLE staff(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,role TEXT,specialty TEXT,department TEXT,phone TEXT,salary REAL,percent REAL,active INTEGER DEFAULT 1)");
        d.execSQL("CREATE TABLE cash(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT,type TEXT,amount REAL,method TEXT,description TEXT,user_name TEXT)");
        d.execSQL("CREATE TABLE audit(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT,user_name TEXT,action TEXT,details TEXT)");
        d.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY,v TEXT)");
        seed(d);
    }
    private void seed(SQLiteDatabase d){
        String[][] s={{"العلاج الطبيعي","قسم الرجال","1500"},{"تأهيل الأطفال","قسم الأطفال","2000"},{"جلسة تغذية علاجية","التغذية العلاجية","3000"},{"جلسة حجامة","الحجامة والمساج","2500"},{"جلسة مساج علاجي","الحجامة والمساج","2500"},{"جلسة صالة رياضية","الصالة الرياضية","1500"}};
        for(String[] x:s)d.execSQL("INSERT INTO services(name,department,price) VALUES(?,?,?)",x);
        putSetting(d,"center_name","المركز الأول للعلاج الطبيعي والتأهيل");
        putSetting(d,"branch","فرع دمت");
        putSetting(d,"phone","770237644 / 733844808 / 713651708");
        putSetting(d,"address","محافظة الضالع - مدينة دمت - شارع الدلة (المتفرع من فرزة يريم) - جوار صالة عامر ومحلات صالح خنداد - أمام محلات الموتى لمواد البناء");
    }
    private void putSetting(SQLiteDatabase d,String k,String v){d.execSQL("INSERT OR REPLACE INTO settings(k,v) VALUES(?,?)",new Object[]{k,v});}
    public void onUpgrade(SQLiteDatabase d,int oldV,int newV){
        if(oldV<2){try{d.execSQL("ALTER TABLE patients ADD COLUMN service TEXT");}catch(Exception ignored){}}
        if(oldV<3){try{d.execSQL("ALTER TABLE patients ADD COLUMN gender TEXT");}catch(Exception ignored){}}
        if(oldV<4){ try { d.execSQL("ALTER TABLE patients ADD COLUMN whatsapp TEXT"); } catch(Exception ignored){} }
    }
    public long addPatient(ContentValues v){return getWritableDatabase().insert("patients",null,v);}
    public Cursor patients(String q){return getReadableDatabase().rawQuery("SELECT * FROM patients WHERE name LIKE ? OR phone LIKE ? OR file_no LIKE ? ORDER BY id DESC",new String[]{"%"+q+"%","%"+q+"%","%"+q+"%"});}
    public Cursor all(String table){return getReadableDatabase().rawQuery("SELECT * FROM "+table+" ORDER BY id DESC",null);}
    public Cursor query(String sql,String[] args){return getReadableDatabase().rawQuery(sql,args);}
    public long insert(String table,ContentValues v){return getWritableDatabase().insert(table,null,v);}
    public int update(String table,ContentValues v,String where,String[] args){return getWritableDatabase().update(table,v,where,args);}
    public String setting(String k){Cursor c=query("SELECT v FROM settings WHERE k=?",new String[]{k});String v="";if(c.moveToFirst())v=c.getString(0);c.close();return v;}
    public void log(String action,String details){ContentValues v=new ContentValues();v.put("date",now());v.put("user_name","المستخدم");v.put("action",action);v.put("details",details);insert("audit",v);}
    public static String now(){return new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date());}
    public static String today(){return new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
}
