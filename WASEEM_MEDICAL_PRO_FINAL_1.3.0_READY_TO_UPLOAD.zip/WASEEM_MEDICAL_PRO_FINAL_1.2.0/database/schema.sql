-- WASEEM MEDICAL PRO - production schema reference
-- Android demo currently uses SQLiteOpenHelper in app/src/main/java/com/waseem/medical/DB.java.
-- This file documents the entities to migrate to PostgreSQL in the cloud edition.
CREATE TABLE IF NOT EXISTS patients(id BIGSERIAL PRIMARY KEY, file_no TEXT UNIQUE NOT NULL, name TEXT NOT NULL, phone TEXT, address TEXT, gender TEXT, birth DATE, case_name TEXT, service TEXT, department TEXT, notes TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS staff(id BIGSERIAL PRIMARY KEY, name TEXT NOT NULL, role TEXT, specialty TEXT, department TEXT, phone TEXT, salary NUMERIC(14,2), percent NUMERIC(6,2), active BOOLEAN DEFAULT TRUE);
CREATE TABLE IF NOT EXISTS services(id BIGSERIAL PRIMARY KEY, name TEXT NOT NULL, department TEXT, price NUMERIC(14,2) DEFAULT 0, active BOOLEAN DEFAULT TRUE);
CREATE TABLE IF NOT EXISTS appointments(id BIGSERIAL PRIMARY KEY, patient_id BIGINT REFERENCES patients(id), date DATE NOT NULL, time TIME NOT NULL, doctor TEXT, service TEXT, status TEXT, notes TEXT);
CREATE TABLE IF NOT EXISTS sessions(id BIGSERIAL PRIMARY KEY, patient_id BIGINT REFERENCES patients(id), date TIMESTAMPTZ NOT NULL DEFAULT now(), service TEXT, doctor TEXT, notes TEXT, package_id BIGINT);
CREATE TABLE IF NOT EXISTS invoices(id BIGSERIAL PRIMARY KEY, patient_id BIGINT REFERENCES patients(id), date TIMESTAMPTZ NOT NULL DEFAULT now(), total NUMERIC(14,2) NOT NULL, paid NUMERIC(14,2) DEFAULT 0, method TEXT, notes TEXT);
CREATE TABLE IF NOT EXISTS payments(id BIGSERIAL PRIMARY KEY, patient_id BIGINT REFERENCES patients(id), date TIMESTAMPTZ NOT NULL DEFAULT now(), amount NUMERIC(14,2) NOT NULL, method TEXT, notes TEXT);
CREATE TABLE IF NOT EXISTS audit(id BIGSERIAL PRIMARY KEY, date TIMESTAMPTZ NOT NULL DEFAULT now(), user_name TEXT, action TEXT NOT NULL, details TEXT);
