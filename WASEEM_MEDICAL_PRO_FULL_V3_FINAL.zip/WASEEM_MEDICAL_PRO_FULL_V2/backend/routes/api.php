<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\PatientController;
use App\Http\Controllers\Api\AppointmentController;
use App\Http\Controllers\Api\SessionController;

Route::prefix('v1')->group(function () {
    Route::post('/auth/login', [AuthController::class, 'login']);
    Route::middleware('auth:sanctum')->group(function () {
        Route::get('/me', [AuthController::class, 'me']);
        Route::apiResource('patients', PatientController::class);
        Route::apiResource('appointments', AppointmentController::class)->except(['show']);
        Route::put('/appointments/{appointment}/status', [AppointmentController::class, 'status']);
        Route::apiResource('sessions', SessionController::class)->except(['show']);
    });
});
