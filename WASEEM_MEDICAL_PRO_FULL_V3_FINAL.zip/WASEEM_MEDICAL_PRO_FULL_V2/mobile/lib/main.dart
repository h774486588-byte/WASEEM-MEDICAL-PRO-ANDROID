import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

const Color navy = Color(0xFF123A56);
const Color blue = Color(0xFF1E74B0);
const Color pageBackground = Color(0xFFF4F7FA);

void main() {
  runApp(const WaseemMedicalApp());
}

class WaseemMedicalApp extends StatefulWidget {
  const WaseemMedicalApp({super.key});

  @override
  State<WaseemMedicalApp> createState() => _WaseemMedicalAppState();
}

class _WaseemMedicalAppState extends State<WaseemMedicalApp> {
  ThemeMode themeMode = ThemeMode.light;

  void toggleTheme() {
    setState(() {
      themeMode = themeMode == ThemeMode.light ? ThemeMode.dark : ThemeMode.light;
    });
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData lightTheme = ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: blue),
      scaffoldBackgroundColor: pageBackground,
      fontFamily: 'sans-serif',
      inputDecorationTheme: const InputDecorationTheme(
        border: OutlineInputBorder(),
        filled: true,
        fillColor: Colors.white,
      ),
    );

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'نظام وسيم الطبي PRO',
      theme: lightTheme,
      darkTheme: ThemeData.dark(useMaterial3: true),
      themeMode: themeMode,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: LoginPage(onToggleTheme: toggleTheme),
    );
  }
}

class LoginPage extends StatefulWidget {
  final VoidCallback onToggleTheme;

  const LoginPage({super.key, required this.onToggleTheme});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController usernameController = TextEditingController(text: 'admin');
  final TextEditingController passwordController = TextEditingController(text: '1234');
  bool loading = false;
  bool obscurePassword = true;

  @override
  void dispose() {
    usernameController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  Future<void> login() async {
    FocusScope.of(context).unfocus();
    setState(() => loading = true);
    await Future<void>.delayed(const Duration(milliseconds: 300));

    final bool valid = usernameController.text.trim().toLowerCase() == 'admin' &&
        passwordController.text == '1234';

    if (!mounted) return;

    if (valid) {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setBool('logged_in', true);
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(builder: (_) => const MainShell()),
      );
    } else {
      setState(() => loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('اسم المستخدم أو كلمة المرور غير صحيحة')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          actions: [
            IconButton(
              tooltip: 'تبديل المظهر',
              onPressed: widget.onToggleTheme,
              icon: const Icon(Icons.brightness_6_outlined),
            ),
          ],
        ),
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(22),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 520),
                child: Column(
                  children: [
                    Container(
                      height: 120,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: navy,
                        borderRadius: BorderRadius.circular(28),
                      ),
                      child: const Center(
                        child: Icon(Icons.add, color: Colors.white, size: 68),
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'نظام وسيم الطبي PRO',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      'إدارة المراكز والعيادات والعلاج الطبيعي والتأهيل',
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 22),
                    Card(
                      elevation: 1,
                      child: Padding(
                        padding: const EdgeInsets.all(20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            const Text(
                              'بيانات الدخول',
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 16),
                            TextField(
                              controller: usernameController,
                              decoration: const InputDecoration(
                                labelText: 'اسم المستخدم',
                                prefixIcon: Icon(Icons.person_outline),
                              ),
                            ),
                            const SizedBox(height: 12),
                            TextField(
                              controller: passwordController,
                              obscureText: obscurePassword,
                              onSubmitted: (_) => login(),
                              decoration: InputDecoration(
                                labelText: 'كلمة المرور',
                                prefixIcon: const Icon(Icons.lock_outline),
                                suffixIcon: IconButton(
                                  onPressed: () => setState(() => obscurePassword = !obscurePassword),
                                  icon: Icon(
                                    obscurePassword ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(height: 18),
                            SizedBox(
                              height: 54,
                              child: FilledButton.icon(
                                onPressed: loading ? null : login,
                                icon: loading
                                    ? const SizedBox(
                                        width: 20,
                                        height: 20,
                                        child: CircularProgressIndicator(strokeWidth: 2),
                                      )
                                    : const Icon(Icons.login),
                                label: Text(loading ? 'جارٍ الدخول...' : 'دخول إلى النظام'),
                              ),
                            ),
                            const SizedBox(height: 10),
                            const Text(
                              'حساب التجربة: admin / 1234',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: Colors.grey),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'تطوير وتصميم: وسيم الفرح لخدمات التقنية والأنظمة\n774486588',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int selectedIndex = 0;

  final List<Widget> pages = const [
    DashboardPage(),
    PatientsPage(),
    AppointmentsPage(),
    SessionsPage(),
    MorePage(),
  ];

  Future<void> logout() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool('logged_in', false);
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute<void>(
        builder: (_) => LoginPage(onToggleTheme: () {}),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: navy,
          foregroundColor: Colors.white,
          title: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('نظام وسيم الطبي PRO', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              Text('المركز الأول للعلاج الطبيعي والتأهيل – دمت', style: TextStyle(fontSize: 10)),
            ],
          ),
          actions: [
            IconButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('لا توجد تنبيهات جديدة')),
                );
              },
              icon: const Icon(Icons.notifications_none),
            ),
            PopupMenuButton<String>(
              onSelected: (String value) {
                if (value == 'logout') logout();
              },
              itemBuilder: (BuildContext context) => const [
                PopupMenuItem<String>(value: 'logout', child: Text('تسجيل الخروج')),
              ],
            ),
          ],
        ),
        body: IndexedStack(index: selectedIndex, children: pages),
        bottomNavigationBar: NavigationBar(
          selectedIndex: selectedIndex,
          onDestinationSelected: (int value) => setState(() => selectedIndex = value),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'المرضى'),
            NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'المواعيد'),
            NavigationDestination(icon: Icon(Icons.healing_outlined), selectedIcon: Icon(Icons.healing), label: 'الجلسات'),
            NavigationDestination(icon: Icon(Icons.menu), label: 'المزيد'),
          ],
        ),
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(color: navy, borderRadius: BorderRadius.circular(20)),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('مرحبًا بك 👋', style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.bold)),
              SizedBox(height: 7),
              Text('إدارة المرضى والمواعيد والجلسات والحسابات من مكان واحد.', style: TextStyle(color: Colors.white70)),
            ],
          ),
        ),
        const SizedBox(height: 16),
        const SectionTitle('إحصائيات اليوم'),
        GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 2,
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1.45,
          children: const [
            StatCard(title: 'المرضى', value: '245', icon: Icons.people_outline),
            StatCard(title: 'مواعيد اليوم', value: '18', icon: Icons.calendar_today),
            StatCard(title: 'جلسات اليوم', value: '12', icon: Icons.healing),
            StatCard(title: 'المقبوضات', value: '85,000 ريال', icon: Icons.payments_outlined),
          ],
        ),
        const SizedBox(height: 18),
        const SectionTitle('الوصول السريع'),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: const [
            QuickAction(title: 'الفواتير', icon: Icons.receipt_long),
            QuickAction(title: 'الباقات', icon: Icons.inventory_2_outlined),
            QuickAction(title: 'الكادر الطبي', icon: Icons.medical_services_outlined),
            QuickAction(title: 'الحسابات والخزينة', icon: Icons.account_balance_wallet_outlined),
            QuickAction(title: 'المخزون', icon: Icons.warehouse_outlined),
            QuickAction(title: 'التقارير', icon: Icons.bar_chart_outlined),
          ],
        ),
      ],
    );
  }
}

class StatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const StatCard({super.key, required this.title, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Icon(icon, color: blue, size: 30),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(color: Colors.grey)),
                  const SizedBox(height: 4),
                  FittedBox(
                    fit: BoxFit.scaleDown,
                    alignment: Alignment.centerRight,
                    child: Text(value, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class QuickAction extends StatelessWidget {
  final String title;
  final IconData icon;

  const QuickAction({super.key, required this.title, required this.icon});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 150,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            children: [
              Icon(icon, color: blue, size: 28),
              const SizedBox(height: 8),
              Text(title, textAlign: TextAlign.center),
            ],
          ),
        ),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title;

  const SectionTitle(this.title, {super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: navy)),
    );
  }
}

class PatientsPage extends StatefulWidget {
  const PatientsPage({super.key});

  @override
  State<PatientsPage> createState() => _PatientsPageState();
}

class _PatientsPageState extends State<PatientsPage> {
  final TextEditingController searchController = TextEditingController();
  final List<Map<String, String>> patients = [
    {'no': 'PT-0001', 'name': 'أحمد محمد', 'phone': '770000000', 'service': 'علاج طبيعي'},
    {'no': 'PT-0002', 'name': 'محمد علي', 'phone': '733000000', 'service': 'تأهيل عصبي'},
  ];

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  Future<void> showPatientForm() async {
    final TextEditingController nameController = TextEditingController();
    final TextEditingController phoneController = TextEditingController();
    DateTime? dateOfBirth;

    await showDialog<void>(
      context: context,
      builder: (BuildContext dialogContext) {
        return StatefulBuilder(
          builder: (BuildContext ctx, StateSetter setDialogState) {
            return AlertDialog(
              title: const Text('إضافة مريض جديد'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(controller: nameController, decoration: const InputDecoration(labelText: 'الاسم الثلاثي')),
                    const SizedBox(height: 12),
                    TextField(
                      controller: phoneController,
                      keyboardType: TextInputType.phone,
                      decoration: const InputDecoration(labelText: 'رقم الهاتف'),
                    ),
                    const SizedBox(height: 12),
                    OutlinedButton.icon(
                      onPressed: () async {
                        final DateTime? picked = await showDatePicker(
                          context: ctx,
                          firstDate: DateTime(1900),
                          lastDate: DateTime.now(),
                          initialDate: dateOfBirth ?? DateTime(2000),
                          locale: const Locale('ar'),
                        );
                        if (picked != null) {
                          setDialogState(() => dateOfBirth = picked);
                        }
                      },
                      icon: const Icon(Icons.calendar_month),
                      label: Text(
                        dateOfBirth == null
                            ? 'تاريخ الميلاد: DD/MM/YYYY'
                            : 'تاريخ الميلاد: ${DateFormat('dd/MM/yyyy').format(dateOfBirth!)}',
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إلغاء')),
                FilledButton(
                  onPressed: () {
                    final String name = nameController.text.trim();
                    if (name.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('يرجى إدخال اسم المريض')));
                      return;
                    }
                    setState(() {
                      patients.insert(0, {
                        'no': 'PT-${(patients.length + 1).toString().padLeft(4, '0')}',
                        'name': name,
                        'phone': phoneController.text.trim(),
                        'service': 'غير محدد',
                      });
                    });
                    Navigator.pop(dialogContext);
                  },
                  child: const Text('حفظ'),
                ),
              ],
            );
          },
        );
      },
    );

    nameController.dispose();
    phoneController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final String query = searchController.text.trim();
    final Iterable<Map<String, String>> filtered = patients.where(
      (Map<String, String> patient) => query.isEmpty || patient.values.any((String value) => value.contains(query)),
    );

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            const Expanded(child: SectionTitle('المرضى والملفات')),
            FilledButton.icon(onPressed: showPatientForm, icon: const Icon(Icons.add), label: const Text('مريض جديد')),
          ],
        ),
        TextField(
          controller: searchController,
          onChanged: (_) => setState(() {}),
          decoration: const InputDecoration(
            prefixIcon: Icon(Icons.search),
            hintText: 'ابحث بالاسم أو الهاتف أو رقم الملف',
          ),
        ),
        const SizedBox(height: 12),
        ...filtered.map(
          (Map<String, String> patient) => Card(
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: blue,
                child: Text(patient['no']!.split('-').last, style: const TextStyle(color: Colors.white)),
              ),
              title: Text(patient['name']!),
              subtitle: Text('${patient['no']} • ${patient['phone']}\n${patient['service']}'),
              isThreeLine: true,
              trailing: const Icon(Icons.chevron_left),
            ),
          ),
        ),
      ],
    );
  }
}

class AppointmentsPage extends StatelessWidget {
  const AppointmentsPage({super.key});

  Future<void> pickAppointmentDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      initialDate: DateTime.now(),
      locale: const Locale('ar'),
    );
    if (picked != null && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تم اختيار التاريخ: ${DateFormat('dd/MM/yyyy').format(picked)}')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            const Expanded(child: SectionTitle('المواعيد')),
            FilledButton.icon(
              onPressed: () => pickAppointmentDate(context),
              icon: const Icon(Icons.add),
              label: const Text('موعد'),
            ),
          ],
        ),
        const Card(
          child: ListTile(
            leading: CircleAvatar(child: Icon(Icons.person)),
            title: Text('أحمد محمد – جلسة علاج طبيعي'),
            subtitle: Text('16/09/2026 • 10:00 • أخصائي العلاج الطبيعي'),
            trailing: Chip(label: Text('مؤكد')),
          ),
        ),
        const Card(
          child: ListTile(
            leading: CircleAvatar(child: Icon(Icons.person)),
            title: Text('محمد علي – متابعة'),
            subtitle: Text('16/09/2026 • 12:00 • عيادة المخ والأعصاب'),
            trailing: Chip(label: Text('محجوز')),
          ),
        ),
      ],
    );
  }
}

class SessionsPage extends StatelessWidget {
  const SessionsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            const Expanded(child: SectionTitle('الجلسات العلاجية')),
            FilledButton.icon(onPressed: () {}, icon: const Icon(Icons.add), label: const Text('تسجيل جلسة')),
          ],
        ),
        const Card(
          child: ListTile(
            title: Text('أحمد محمد'),
            subtitle: Text('علاج طبيعي • 16/09/2026'),
            trailing: Text('جلسة مكتملة'),
          ),
        ),
      ],
    );
  }
}

class MorePage extends StatelessWidget {
  const MorePage({super.key});

  @override
  Widget build(BuildContext context) {
    const List<String> items = [
      'الفواتير والقبض',
      'كشف الحساب',
      'الباقات العلاجية',
      'الأطباء والمعالجون',
      'دليل الخدمات والأسعار',
      'الحسابات والخزينة',
      'المخزون والجرد',
      'الرسائل وWhatsApp/SMS',
      'التقارير والتصدير',
      'الإعدادات',
      'النسخ الاحتياطي',
      'الترخيص والاشتراك',
    ];

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const SectionTitle('المزيد'),
        ...items.map(
          (String item) => Card(
            child: ListTile(
              title: Text(item),
              trailing: const Icon(Icons.chevron_left),
              onTap: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('وحدة $item جاهزة للربط بالوظائف المتقدمة')),
                );
              },
            ),
          ),
        ),
      ],
    );
  }
}
