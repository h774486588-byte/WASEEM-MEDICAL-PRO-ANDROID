# Waseem Medical PRO

Flutter mobile client + Laravel/PostgreSQL backend foundation for the Waseem Medical PRO platform.

## GitHub build
Use `.github/workflows/build-apk.yml`. The workflow expects the project ZIP in the repository, extracts it, locates `pubspec.yaml`, then runs Flutter `pub get`, `flutter analyze`, and `flutter build apk --release`.

Demo login: `admin` / `1234`

Date display: `DD/MM/YYYY`.
